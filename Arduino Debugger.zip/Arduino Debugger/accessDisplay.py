import serial
import time

arduino_port = '/dev/cu.usbmodem113301'  
arduino = serial.Serial(arduino_port, 9600, timeout=1)
time.sleep(2)  # allow Arduino to reset

print("Arduino connected. Type your text and press Enter.\n")

while True:
    try:
        line = arduino.readline().decode('utf-8', errors='ignore').strip()
        if not line:
            continue

        # Detect start marker for robust reading
        if line == ">>>PROMPT_START<<<":
            prompt_line = arduino.readline().decode('utf-8', errors='ignore').strip()
            if prompt_line.startswith("PROMPT:"):
                print("✓ Prompt from Arduino:", prompt_line[len("PROMPT:"):].strip())

        elif line == ">>>EMAIL_START<<<":
            email_line = arduino.readline().decode('utf-8', errors='ignore').strip()
            if email_line.startswith("EMAIL:"):
                print("✓ Email from Arduino:", email_line[len("EMAIL:"):].strip())

    except KeyboardInterrupt:
        print("\nExiting...")
        break
    except Exception as e:
        print("Error:", e)