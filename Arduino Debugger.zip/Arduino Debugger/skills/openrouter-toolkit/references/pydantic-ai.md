# PydanticAI with OpenRouter

Use this reference when building richer agents that require validation, tools, or deterministic chains. Review the official adapter docs before extending: https://ai.pydantic.dev/models/openrouter/index.md

## Installation
```bash
pip install "pydantic-ai[openrouter]" python-dotenv
```

Ensure `.env` contains `OPENROUTER_API_KEY`.

## Agent Pattern
The bundled `scripts/pydantic_agent.py` demonstrates the minimal wiring:
1. Configure `MODEL_ID` at the top (e.g., `openrouter/anthropic/claude-3.5-sonnet`).  
2. Initialize `OpenRouterModel(MODEL_ID, default_headers=...)`.  
3. Create a `Agent` with system prompt + response `ModelResponse` schema.  
4. Register any tools using `@agent.tool` decorators.  
5. Call `agent.run("task description")`.

## Tips
- Keep schemas small and descriptive so validation errors are actionable.  
- Use `response_format` (`return_type`) to coerce structured data; OpenRouter models that support JSON mode will honor it automatically.  
- Place temperature/max tokens either in `OpenRouterSettings` or per-call overrides (see doc link above).  
- For workflows that still need streaming, wrap the final call with `agent.run_stream()` and handle events manually; otherwise prefer the default blocking run to keep logs simple.

## Debugging
- Set `OPENROUTER_LOG_LEVEL=debug` (env var) to inspect request/response logs emitted by the adapter.  
- Handle `PydanticAiError` exceptions to surface validation or HTTP errors to the user.  
- Use the `--json` flag inside `scripts/pydantic_agent.py` to view the raw OpenRouter payload when diagnosing schema mismatches.

