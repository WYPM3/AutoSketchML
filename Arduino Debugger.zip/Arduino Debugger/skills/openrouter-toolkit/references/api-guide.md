# OpenRouter API Notes

High-level reminders for structuring OpenRouter requests without duplicating the canonical docs. Load `https://openrouter.ai/docs/llms.txt` whenever you need the full spec.

## Endpoints Used in This Skill

| Endpoint | Method | Purpose |
| --- | --- | --- |
| `/models` | GET | List current models, providers, pricing, modality support, context windows |
| `/chat/completions` | POST | Run chat-style inference and (optionally) stream responses |

## Required Headers
- `Authorization: Bearer <OPENROUTER_API_KEY>` — keep the key in `.env`.  
- `HTTP-Referer` — identifies your integration/site domain. For local experiments use `http://localhost`.  
- `X-Title` — short descriptor (e.g., "Oneshot Playground").  
- `Content-Type: application/json`.  
Leaving out `HTTP-Referer` or `X-Title` can result in rejected requests when hitting production rate limits, so the provided scripts set defaults.

## Request Body Cheatsheet
```json
{
  "model": "openrouter/anthropic/claude-3.5-sonnet",
  "messages": [
    {
      "role": "system",
      "content": [{"type": "text", "text": "Keep answers concise."}]
    },
    {
      "role": "user",
      "content": [
        {"type": "text", "text": "Summarize our product roadmap."},
        {"type": "text", "text": "Attachment: roadmap.txt\n<file contents>"}
      ]
    }
  ],
  "temperature": 0.2,
  "max_tokens": 1024,
  "stream": false
}
```

Notes:
- Content MUST be a list of objects. Use `type: "text"` for plain strings; map other modalities per the doc index.  
- When streaming, `stream: true` returns `data: {json}\n` chunks ending with `[DONE]`.  
- Price/capabilities vary per model; consult `/models` or the docs index before selecting.

## Rate & Error Handling
- `429` indicates exhausted rate limits; respect `Retry-After`.  
- `401`/`403` typically mean an invalid or missing key/headers.  
- `422` surfaces validation errors inside `error` + `message`; bubble these up to the user rather than hiding them.

