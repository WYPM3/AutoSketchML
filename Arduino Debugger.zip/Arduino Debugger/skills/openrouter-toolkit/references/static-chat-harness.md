# Static Chat Harness

`assets/chat-harness/index.html` is a self-contained artifact that can be dropped into claude.ai, Netlify Drop, GitHub Pages, or any other static host. It enables quick manual chops with OpenRouter without deploying a backend.

## Features
- Client-side settings drawer where users paste their API key (persisted via `localStorage` only on the device). Keys must start with `sk-or-` and the UI prepends `Bearer` automatically.  
- Live model dropdown hydrated from `scripts/list_models.py --dump` or the baked-in preference list (general, coding, multimodal, embeddings).  
- Stateful chat transcript: every turn is replayed into the next request. Toggling **Persist transcript** additionally saves the log to `localStorage`; turning it off keeps the transcript only for the current tab session.  
- Streaming responses via `ReadableStream`: the harness buffers SSE blocks, skips `OPENROUTER PROCESSING`, and normalizes both `delta.content` and `delta.images` chunks so tokens appear incrementally.  
- Optional file attachments: text/markdown files are inlined and image files are converted to data URLs and posted as `input_image` parts.  
- Generated images are rendered inline—Gemini’s `delta.images` arrays, `output[]` objects, and classic `image_url` payloads all resolve to thumbnails with download links.

## Customization Workflow
1. Drop in the latest models JSON (if desired) by editing `window.DEFAULT_MODELS` in the `<script>` tag.  
2. Update the hero/system prompt copy to explain the specific use case.  
3. Modify styling in the `<style>` block or attach your own CSS.  
4. When complete, select the whole HTML file and provide it as an artifact or host it statically.

## Local Testing
```bash
npx serve skills/openrouter-toolkit/assets/chat-harness
# or
python3 -m http.server --directory skills/openrouter-toolkit/assets/chat-harness 4173
```
Open `http://localhost:4173/index.html`, paste an API key inside **Settings → API Key**, choose a model, and start chatting.

**Important**: Serve the harness over `http://` or `https://`. Loading it from `file://` (double-clicking in Finder/Explorer) prevents the browser from sending the `Authorization` header and results in `{"error":{"message":"No auth credentials found"}}`. When deploying, set the **HTTP Referer** field in the UI to match your actual domain and keep the X-Title descriptive.

## Streaming & Multimodal Notes
- The SSE parser handles three shapes documented in [OpenRouter’s multimodal guide](https://openrouter.ai/docs/docs/overview/multimodal/image-generation.mdx):  
  1. Classic `delta.content` text parts  
  2. `delta.images` arrays that embed base64 blobs or hosted URLs (Gemini)  
  3. Top-level `output[]` items (used by Gemini image endpoints)  
- Each block is normalized into `text` or `image_url` entries and mirrored inside the assistant bubble + history.  
- Errors are rendered inline with the assistant bubble; open the browser console for HTTP or parsing messages.  
- Use **Persist transcript** when you want to reload the page without losing context; disable it for ephemeral chats.

## Image Outputs
- When a streamed chunk contains an image, the harness appends a thumbnail that links to the generated asset (and sets `download` so users can save the file).  
- Data URLs are generated for any base64-only models, and hosted URLs remain intact.  
- Extend `appendImage()` if you need captions, galleries, or automatic artifact exports.

## Security Considerations
- API keys never leave the browser except in the request to `https://openrouter.ai/api/v1/chat/completions`.  
- There is no backend proxy; CORS is supported directly by OpenRouter.  
- Encourage users to clear the stored key using the **Reset** button when finished.
- For shared deployments, remind users to verify domain-specific `HTTP Referer`/`X-Title` values and rotate keys periodically.
