# Multimodal & Image Handling

The OpenRouter API accepts multimodal payloads that follow the same structure as OpenAI chat completions. Use this guide to attach images and interpret image outputs when working from CLI scripts or the static chat harness.

## Input Images (Python)

1. Use the `--image path/to/file.png` flag in `scripts/simple_chat.py` (multiple flags allowed).  
2. Each image is base64-encoded and added to the user message as:
```json
{
  "type": "input_image",
  "image_url": {
    "url": "data:image/png;base64,<BASE64>",
    "detail": "auto"
  }
}
```
3. Additional text attachments can still be included via `--input-file`.  
4. Verify the target model supports vision input (e.g., `google/gemini-2.5-flash`, `google/gemini-3-pro-image-preview`).

## Input Images (Static Harness)

- The **Attach files** control accepts both text and image files.  
- Text files are inlined as additional `type: "text"` parts.  
- Images are converted to `data:` URLs client-side and sent as `input_image` parts (same shape as above).  
- Nothing is uploaded to a backend; everything stays in-browser until sent to OpenRouter.

## Handling Image Outputs

Some models (Gemini 3 Pro image preview) return images under `choices[].message.content[].image_url`. To surface them:

- **Python**: Inspect `choice["message"]["content"]` and download the referenced `image_url["url"]` (typically already a base64 data URL). Save it with the right extension to inspect locally.  
- **Harness**: The SSE parser consumes `delta.images`, `image_url`, or top-level `output[]` entries (see [OpenRouter multimodal docs](https://openrouter.ai/docs/docs/overview/multimodal/image-generation.mdx)). Each chunk is normalized into a `type: "image_url"` part so thumbnails stream into the UI automatically. Extend `appendImage()` if you need automatic downloads or metadata overlays.

### Streaming Chunk Shapes
1. **Classic text**: `delta: { content: [{type:"text", text:"..."}] }`  
2. **Gemini delta images**: `delta: { images: [{ inline_data: { mime_type, data }}] }`  
3. **Gemini output array**: `output: [{ content: { inline_data: { ... }}}]`  
4. **Base64 helpers**: `b64_json`, `image_base64`, or `bytes` fields show up for some providers.

Normalize each chunk into either `{"type":"text","text":"..."}` or `{"type":"image_url","image_url":{"url":"data:..."}}`. The harness already does this; mirror that logic if you build additional tools.

## Tips

- Keep base64 payloads under OpenRouter’s max request size; resize or compress images before sending.  
- Use `detail: "low"` for rough previews when latency matters.  
- Always cite `HTTP-Referer` and `X-Title` headers even when running vision workloads.  
- For multi-image prompts, include each image as its own part so the model can reference them individually.
