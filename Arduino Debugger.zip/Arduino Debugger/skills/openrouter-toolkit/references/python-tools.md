# Python Tooling Patterns

Guidance for extending the bundled Python scripts. These helpers intentionally stay minimal so they can be copied into other repos or invoked directly from this workspace.

## Shared Conventions

- Load credentials via `OPENROUTER_API_KEY` exported from `.env`. The scripts call `dotenv.load_dotenv()` but still fail fast when the variable is missing.  
- Base URL: `https://openrouter.ai/api/v1`.  
- Always send descriptive `HTTP-Referer` and `X-Title` headers to stay within OpenRouter's usage policy (see live docs via `https://openrouter.ai/docs/llms.txt`).  
- Keep `MODEL = "..."` declared near the top of each script to make swaps trivial. Avoid hardcoding it deep in functions.
- Default general-purpose model is `openrouter/openai/gpt-4.1-mini`; override via CLI flags or `OPENROUTER_DEFAULT_MODEL`.

## `scripts/list_models.py`

Usage:
```bash
python3 skills/openrouter-toolkit/scripts/list_models.py --limit 15 --provider anthropic
python3 skills/openrouter-toolkit/scripts/list_models.py --dump models.json --sort tokens_per_second
```

What it does:
1. Calls `GET /models` with your API key.  
2. Prints a table showing model id, pricing, context length, and availability.  
3. Accepts filters (`--provider`, `--search`, `--max-context`) plus export flags (`--dump` JSON, `--csv`).  
4. Reminds you to consult `https://openrouter.ai/docs/llms.txt` for authoritative descriptions of any model you select.

Extension ideas:
- Add cached responses or TTL flags if you plan to hydrate dropdowns repeatedly.  
- Extend CLI arguments to surface modalities (`input_audio`, `image`, etc.) which are provided in the payload.

## `scripts/simple_chat.py`

Usage:
```bash
python3 skills/openrouter-toolkit/scripts/simple_chat.py \
  --prompt "Translate this snippet to Rust" \
  --model "openrouter/meta-llama/llama-3.1-405b-instruct" \
  --image diagrams/ui.png
```

Key behaviors:
- Single-turn calls to `POST /chat/completions`.  
- Non-streaming by default, returning `choices[0].message.content`.  
- Supports `--system` to override the default system message, `--json` to dump the full response, and `--temperature` plus `--max-tokens`.

Implementation tips:
- Reuse the `build_payload()` helper when embedding this logic into other agents; it ensures content is always a list of structured message parts.  
- For multi-turn conversations, persist `messages` in a deque and pass the list back into `run_chat()`. The script shows where to place that hook.
- Use the `--image` flag (repeatable) for multimodal prompts; it base64-encodes attachments and appends `type: "input_image"` parts. See `references/multimodal.md` for full payload examples.
- When a model emits `image_url` parts, the CLI prints an `Images:` section listing the returned data URLs so they can be saved locally.

## Adding New Utilities

1. Copy `scripts/simple_chat.py` into a new script, rename the file, and change the CLI arguments.  
2. Keep API calls isolated inside a function so Claude can easily patch logic (e.g., `def call_openrouter(payload: dict) -> dict`).  
3. Document the new script in `SKILL.md` plus either this file or a new reference file depending on complexity.
