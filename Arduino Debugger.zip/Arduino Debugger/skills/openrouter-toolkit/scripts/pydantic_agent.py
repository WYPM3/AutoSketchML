#!/usr/bin/env python3
"""
PydanticAI agent example for OpenRouter.

Usage:
- Ensure `.env` has `OPENROUTER_API_KEY`.
- Run: `python3 skills/openrouter-toolkit/scripts/pydantic_agent.py "Your task"`  
  Optional: `--system "Custom system prompt"` or `--json` for the raw structured response.
- Demo tools included:
  - `list_workspace(path=".")` to show nearby files/directories.
  - `read_text_file(path)` to load UTF-8 text.
  - `search_text_file(path, query)` to grep a file for a query.
  Replace or extend with your own tools using the same `@agent.tool` pattern.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import AsyncOpenAI
from pydantic import BaseModel, Field
from pydantic_ai import Agent, RunContext
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openrouter import OpenRouterProvider
from pydantic_ai.settings import ModelSettings

MODEL_ID = "openai/gpt-5.1-chat"
MAX_TURNS = 10
DEFAULT_SYSTEM_MESSAGE = (
    "You are an organized research assistant. Return a short markdown summary plus follow-up tasks."
)


class ResearchResponse(BaseModel):
    """Structured result for downstream agents."""

    summary: str = Field(..., description="Concise answer to the user request.")
    follow_ups: list[str] = Field(
        default_factory=list, description="Optional follow-up tasks or open questions."
    )


def load_api_key() -> str:
    load_dotenv()
    key = os.getenv("OPENROUTER_API_KEY")
    if not key:
        sys.exit("OPENROUTER_API_KEY missing; populate .env first.")
    return key


def build_agent(api_key: str, system: str) -> Agent[ResearchResponse]:
    openrouter_client = AsyncOpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=api_key,
        default_headers={
            "HTTP-Referer": os.getenv("OPENROUTER_REFERER", "http://localhost"),
            "X-Title": os.getenv("OPENROUTER_TITLE", "OpenRouter Toolkit Agent"),
        },
    )
    model = OpenAIChatModel(
        model_name=MODEL_ID,
        provider=OpenRouterProvider(openai_client=openrouter_client),
    )
    agent = Agent(
        model=model,
        instructions=system,
        output_type=ResearchResponse,
        model_settings=ModelSettings(max_messages=MAX_TURNS),
    )

    @agent.tool
    def read_text_file(ctx: RunContext[None], path: str) -> str:
        """Load UTF-8 text from the workspace."""
        print(f"[tool] read_text_file path={path}", flush=True)
        file_path = Path(path)
        if not file_path.exists():
            return f"[file not found: {path}]"
        content = file_path.read_text(encoding="utf-8")
        print(f"[tool] read_text_file result ({len(content)} chars)", flush=True)
        return content

    @agent.tool
    def list_workspace(ctx: RunContext[None], path: str = ".") -> str:
        """List files/directories relative to the workspace."""
        print(f"[tool] list_workspace path={path}", flush=True)
        base = Path(path)
        if not base.exists():
            return f"[path not found: {path}]"
        entries = []
        for child in sorted(base.iterdir()):
            suffix = "/" if child.is_dir() else ""
            entries.append(f"{child.name}{suffix}")
        output = "\n".join(entries)
        print(f"[tool] list_workspace result:\n{output}", flush=True)
        return output

    @agent.tool
    def search_text_file(ctx: RunContext[None], path: str, query: str) -> str:
        """Return matching lines for a query inside a UTF-8 text file."""
        print(f"[tool] search_text_file path={path} query={query}", flush=True)
        file_path = Path(path)
        if not file_path.exists():
            return f"[file not found: {path}]"
        lines = file_path.read_text(encoding="utf-8").splitlines()
        matches = []
        for idx, line in enumerate(lines, start=1):
            if query.lower() in line.lower():
                matches.append(f"{idx}: {line}")
        output = "\n".join(matches) if matches else "[no matches]"
        print(f"[tool] search_text_file result:\n{output}", flush=True)
        return output

    return agent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a PydanticAI agent via OpenRouter.")
    parser.add_argument("prompt", help="Task or question for the agent")
    parser.add_argument(
        "--system",
        default=DEFAULT_SYSTEM_MESSAGE,
        help="System instructions for the agent",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print full JSON response instead of formatted summary",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    api_key = load_api_key()
    agent = build_agent(api_key, args.system)
    print(f"[agent] model={MODEL_ID} max_turns={MAX_TURNS}", flush=True)
    print(f"[agent] prompt={args.prompt}", flush=True)
    result = agent.run_sync(args.prompt)
    if args.json:
        print(result.output.model_dump_json(indent=2))
        return

    summary = result.output.summary
    if result.output.follow_ups:
        follow = "\n".join(f"- {item}" for item in result.output.follow_ups)
        print(f"{summary}\n\nFollow-ups:\n{follow}")
    else:
        print(summary)


if __name__ == "__main__":
    main()
