#!/usr/bin/env python3
"""Generic non-streaming OpenRouter chat helper for quick one-offs.

Pass a user prompt (stdin or --prompt/--prompt-file), optionally override the model, and set a system message when needed.
"""
from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import sys
from pathlib import Path
from typing import Any

import requests
from dotenv import load_dotenv

API_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL = os.getenv("OPENROUTER_DEFAULT_MODEL", "openai/gpt-4.1-mini")


def load_api_key() -> str:
    load_dotenv()
    key = os.getenv("OPENROUTER_API_KEY")
    if not key:
        sys.exit("Missing OPENROUTER_API_KEY in environment/.env.")
    return key


def read_prompt(args: argparse.Namespace) -> str:
    if args.prompt:
        return args.prompt
    if args.prompt_file:
        return Path(args.prompt_file).read_text(encoding="utf-8")
    data = sys.stdin.read().strip()
    if data:
        return data
    sys.exit("Provide --prompt, --prompt-file, or stdin input.")


def build_image_part(path: Path) -> dict[str, Any]:
    if not path.exists():
        sys.exit(f"Image file not found: {path}")
    data = path.read_bytes()
    encoded = base64.b64encode(data).decode("utf-8")
    mime, _ = mimetypes.guess_type(path.name)
    mime = mime or "image/png"
    return {
        "type": "input_image",
        "image_url": {
            "url": f"data:{mime};base64,{encoded}",
            "detail": "auto",
        },
    }


def build_payload(prompt: str, args: argparse.Namespace) -> dict[str, Any]:
    user_content = [{"type": "text", "text": prompt}]
    for attachment in args.input_file or []:
        path = Path(attachment)
        user_content.append(
            {
                "type": "text",
                "text": f"Attachment: {path.name}\n{path.read_text(encoding='utf-8')}",
            }
        )
    for image_path in args.image or []:
        user_content.append(build_image_part(Path(image_path)))

    payload: dict[str, Any] = {
        "model": args.model or MODEL,
        "messages": [
            {
                "role": "system",
                "content": [{"type": "text", "text": args.system}],
            },
            {"role": "user", "content": user_content},
        ],
        "temperature": args.temperature,
        "max_tokens": args.max_tokens,
        "stream": False,
    }
    if args.response_format == "json":
        payload["response_format"] = {"type": "json_object"}
    return payload


def call_openrouter(payload: dict[str, Any], key: str) -> dict[str, Any]:
    headers = {
        "Authorization": f"Bearer {key}",
        "HTTP-Referer": os.getenv("OPENROUTER_REFERER", "http://localhost"),
        "X-Title": os.getenv("OPENROUTER_TITLE", "OpenRouter Toolkit Simple Chat"),
        "Content-Type": "application/json",
    }
    response = requests.post(API_URL, headers=headers, json=payload, timeout=60)
    response.raise_for_status()
    return response.json()


def extract_text(data: dict[str, Any]) -> str:
    try:
        choice = data["choices"][0]
        parts = choice["message"]["content"]
        if isinstance(parts, list):
            text_segments = []
            image_urls = []
            for part in parts:
                if "text" in part and part.get("text"):
                    text_segments.append(part["text"])
                image_url = part.get("image_url")
                if isinstance(image_url, dict) and image_url.get("url"):
                    image_urls.append(image_url["url"])
            output = "".join(text_segments).strip()
            if image_urls:
                images_block = "\n".join(image_urls)
                output = (
                    f"{output}\n\nImages:\n{images_block}"
                    if output
                    else f"Images:\n{images_block}"
                )
            return output or json.dumps(data, indent=2)
        return str(parts)
    except (KeyError, IndexError):
        return json.dumps(data, indent=2)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Simple OpenRouter chat helper.")
    parser.add_argument("--prompt", help="Inline prompt text")
    parser.add_argument("--prompt-file", help="Path to prompt file")
    parser.add_argument(
        "--input-file",
        action="append",
        help="Attach file contents as extra message parts (text only)",
    )
    parser.add_argument("--model", help=f"Override model id (default: {MODEL})")
    parser.add_argument(
        "--system",
        default="Answer as a concise assistant.",
        help="System message",
    )
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--max-tokens", type=int, default=1024)
    parser.add_argument(
        "--image",
        action="append",
        help="Attach image file(s) for multimodal prompts (PNG/JPEG/etc.)",
    )
    parser.add_argument(
        "--response-format", choices=["text", "json"], default="text", help="Request JSON mode"
    )
    parser.add_argument(
        "--json", action="store_true", help="Print raw JSON response instead of text"
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    prompt = read_prompt(args)
    payload = build_payload(prompt, args)
    key = load_api_key()
    data = call_openrouter(payload, key)
    if args.json:
        print(json.dumps(data, indent=2))
    else:
        print(extract_text(data).strip())


if __name__ == "__main__":
    try:
        main()
    except requests.HTTPError as exc:
        sys.exit(f"Request failed: {exc} - {exc.response.text}")
