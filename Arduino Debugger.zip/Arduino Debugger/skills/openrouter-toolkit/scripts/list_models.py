#!/usr/bin/env python3
"""
List available OpenRouter models with optional filtering/export helpers.

Usage examples:
  python list_models.py --limit 10
  python list_models.py --provider anthropic --search sonnet --csv models.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path
from typing import Any, Iterable

import requests
from dotenv import load_dotenv

API_URL = "https://openrouter.ai/api/v1/models"
DEFAULT_LIMIT = 25


def load_api_key() -> str:
    load_dotenv()
    key = os.getenv("OPENROUTER_API_KEY")
    if not key:
        sys.exit("Missing OPENROUTER_API_KEY in environment/.env.")
    return key


def fetch_models(key: str) -> list[dict[str, Any]]:
    headers = {
        "Authorization": f"Bearer {key}",
        "HTTP-Referer": os.getenv("OPENROUTER_REFERER", "http://localhost"),
        "X-Title": os.getenv("OPENROUTER_TITLE", "OpenRouter Toolkit"),
    }
    resp = requests.get(API_URL, headers=headers, timeout=30)
    resp.raise_for_status()
    data = resp.json()
    return data.get("data", [])


def filter_models(
    models: Iterable[dict[str, Any]],
    provider: str | None,
    search: str | None,
    max_context: int | None,
) -> list[dict[str, Any]]:
    results = []
    for model in models:
        if provider and provider.lower() not in model.get("id", "").lower():
            continue
        if search:
            haystack = " ".join(
                [model.get("id", ""), str(model.get("description", ""))]
            ).lower()
            if search.lower() not in haystack:
                continue
        if max_context:
            ctx = model.get("context_length") or model.get("context_length_tokens")
            if ctx and ctx > max_context:
                continue
        results.append(model)
    return results


def sort_models(models: list[dict[str, Any]], field: str) -> list[dict[str, Any]]:
    key_funcs = {
        "id": lambda m: m.get("id", ""),
        "input_price": lambda m: (m.get("pricing") or {}).get("prompt", 0),
        "output_price": lambda m: (m.get("pricing") or {}).get("completion", 0),
        "context": lambda m: m.get("context_length")
        or m.get("context_length_tokens")
        or 0,
    }
    fn = key_funcs.get(field, key_funcs["id"])
    return sorted(models, key=fn)


def print_table(models: list[dict[str, Any]], limit: int) -> None:
    if not models:
        print("No models matched the current filters.")
        print("Docs index: https://openrouter.ai/docs/llms.txt")
        return

    headers = ("Model", "Max Ctx", "Prompt", "Completion", "Provider")
    widths = [len(h) for h in headers]
    rows = []
    for model in models[:limit]:
        ctx = model.get("context_length") or model.get("context_length_tokens")
        pricing = model.get("pricing") or {}
        prompt_price = pricing.get("prompt")
        completion_price = pricing.get("completion")
        provider = model.get("organization", {}).get("name", "")
        row = (
            model.get("id", ""),
            f"{ctx:,}" if ctx else "-",
            f"${prompt_price}/1M" if prompt_price else "-",
            f"${completion_price}/1M" if completion_price else "-",
            provider or "-",
        )
        widths = [max(w, len(str(value))) for w, value in zip(widths, row)]
        rows.append(row)

    def fmt(row: tuple[str, ...]) -> str:
        return " | ".join(str(val).ljust(width) for val, width in zip(row, widths))

    print(fmt(headers))
    print("-+-".join("-" * width for width in widths))
    for row in rows:
        print(fmt(row))

    print(f"\nDisplayed {min(limit, len(models))}/{len(models)} models.")
    print("Use scripts/list_models.py --help for export options.")
    print("Docs index: https://openrouter.ai/docs/llms.txt")


def maybe_write(path: Path, models: list[dict[str, Any]], *, csv_mode: bool = False) -> None:
    if not path:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    if csv_mode:
        fieldnames = ["id", "provider", "context_length", "prompt_price", "completion_price"]
        with path.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()
            for model in models:
                pricing = model.get("pricing") or {}
                writer.writerow(
                    {
                        "id": model.get("id"),
                        "provider": (model.get("organization") or {}).get("name"),
                        "context_length": model.get("context_length")
                        or model.get("context_length_tokens"),
                        "prompt_price": pricing.get("prompt"),
                        "completion_price": pricing.get("completion"),
                    }
                )
        print(f"Wrote CSV to {path}")
    else:
        with path.open("w", encoding="utf-8") as fh:
            json.dump(models, fh, indent=2)
        print(f"Wrote JSON to {path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Inspect OpenRouter models.")
    parser.add_argument("--provider", help="Filter by provider substring (e.g. anthropic)")
    parser.add_argument("--search", help="Search across id/description")
    parser.add_argument("--max-context", type=int, help="Only include models <= this context tokens")
    parser.add_argument("--limit", type=int, default=DEFAULT_LIMIT)
    parser.add_argument("--sort", choices=["id", "context", "input_price", "output_price"], default="id")
    parser.add_argument("--dump", type=Path, help="Write raw JSON response to a file")
    parser.add_argument("--csv", type=Path, help="Write summarized CSV to a file")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    key = load_api_key()
    models = fetch_models(key)
    models = filter_models(models, args.provider, args.search, args.max_context)
    models = sort_models(models, args.sort)
    if args.dump:
        maybe_write(args.dump, models)
    if args.csv:
        maybe_write(args.csv, models, csv_mode=True)
    print_table(models, args.limit)


if __name__ == "__main__":
    try:
        main()
    except requests.HTTPError as exc:
        sys.exit(f"OpenRouter API error: {exc} - {exc.response.text}")
