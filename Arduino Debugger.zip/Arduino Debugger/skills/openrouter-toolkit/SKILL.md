---
name: openrouter-toolkit
description: Equips you to rapidly prototype with AI models via OpenRouter gateway service. Help you make scripts, pydantic-ai agents, static chat harnesses.
license: Complete terms in LICENSE.txt
---

# OpenRouter Toolkit
Package of reusable scripts, UI scaffolding, and reference guides for working against the OpenRouter REST API. Keep SKILL.md loaded for workflow guidance and open the reference files only when deeper implementation detail is required.

## When to Use
- Prototype CLI/Python tools that call the OpenRouter `chat/completions` or `models` endpoints
- Build small agents or workers that need deterministic, non-streaming interactions or pydantic-ai orchestration
- Spin up a static chat harness artifact that lets users pick a model, drop in their OpenRouter key client-side, and stream responses

## Core Setup
1. Store the API secret in `.env` as `OPENROUTER_API_KEY=sk-or-...` (never embed it in code or HTML). Client-side harnesses should ask the user to paste their raw `sk-or-...` key (no leading `Bearer`) locally instead of baking it into the bundle. Non-OpenRouter keys (e.g., `sk-proj-...`) are rejected before the harness sends a request.  
2. Load the key before running any Python script. Either `source .env` / `export $(grep OPENROUTER_API_KEY .env | xargs)` or wrap execution with python-dotenv: `python3 -m dotenv run -- python3 skills/openrouter-toolkit/scripts/simple_chat.py ...`.  
3. Use the canonical docs index at `https://openrouter.ai/docs/llms.txt` to find live API/feature docs; this skill links to a few high-signal sections but does not mirror them.  
4. When testing the static harness, always serve it via `http(s)` (e.g., `npx serve` or `python3 -m http.server`). Loading it via `file://` strips the `Authorization` header and triggers `{"error":{"message":"No auth credentials found"}}`.


## Quickstart Snippets

### Python (non-streaming)
```bash
pip install -r requirements.txt requests python-dotenv
python3 skills/openrouter-toolkit/scripts/simple_chat.py \
  --prompt "Summarize today's release notes." \
  --model "openai/gpt-4.1-mini"
```

### Curl
```bash
curl https://openrouter.ai/api/v1/chat/completions \
  -H "Authorization: Bearer $OPENROUTER_API_KEY" \
  -H "HTTP-Referer: https://example.com" \
  -H "X-Title: Local Experiment" \
  -H "Content-Type: application/json" \
  -d '{
        "model": "openai/gpt-4.1-mini",
        "messages": [{"role": "user", "content": "Hello OpenRouter!"}],
        "stream": false
      }'
```

## Preferred Models
| Role | Model ID | Notes |
| --- | --- | --- |
| General workhorse | `openai/gpt-4.1-mini` | Default for scripts/chat harness; fast, balanced cost/perf. |
| Agent orchestrator | `openai/gpt-5.1-chat` | Use when building multi-tool PydanticAI agents or workflow runners. |
| Coding | `openrouter/openai/gpt-5.1-codex` | High-quality code-oriented completions or refactors. |
| Multimodal | `google/gemini-2.5-flash` | Handles mixed text+image inputs and image descriptions. |
| Large-context workloads | `google/gemini-2.5-flash-lite` | Cheaper expanded context for long docs. |
| Image generation & editing | `google/gemini-3-pro-image-preview` | Supports image gen/edit endpoints; chat harness exposes it for quick prompts. |
| Embedding | `openrouter/openai/text-embedding-3-small` | Embedding-only endpoint (not usable with `chat/completions`—invoke via embeddings API). |

## Included Resources
- `scripts/list_models.py` — call the `/models` endpoint, filter/sort locally, and optionally dump to JSON/CSV. Use it immediately when you hit model-id errors to confirm the live identifier and spelling.  
- `scripts/simple_chat.py` — generic non-streaming helper: provide a user prompt (stdin or `--prompt/--prompt-file`), optionally set `--model` to override the default `openai/gpt-4.1-mini`, and `--system` for system behavior. It’s the quickest path to “send prompt, get response.”  
- `scripts/pydantic_agent.py` — PydanticAI agent wired up to OpenRouter for richer tool/validator flows; includes functional demo tools (`list_workspace`, `read_text_file`, `search_text_file`) and caps conversations at `MAX_TURNS=10`.  
- `assets/chat-harness/` — static HTML/JS harness with streaming responses, in-browser API key storage, model picker, and lightweight file-to-message helpers.  
- References in `references/` dive into architecture, harness wiring, Python patterns, PydanticAI usage, and multimodal payloads (`api-guide.md`, `python-tools.md`, `static-chat-harness.md`, `pydantic-ai.md`, `multimodal.md`).  

## Implementation Notes
- **Model discovery**: Prefer `scripts/list_models.py` for local filtering; it also prints the canonical `https://openrouter.ai/docs/llms.txt` pointer so you can jump into official docs for the model you select.  
- **Static chat harness**: Review `references/static-chat-harness.md` before editing `assets/chat-harness/index.html`; it covers hosting requirements (must run over `http(s)`), the `sk-or-` key guard, the persistence toggle (stateful conversations + optional localStorage), and the SSE parser that normalizes `OPENROUTER PROCESSING`, `delta.images`, and top-level `output` arrays so image generations stream in correctly.  
- **Python tooling**: `references/python-tools.md` explains how the provided scripts structure environment loading, request payloads, and logging so you can extend them safely.  
- **Pydantic agents**: `references/pydantic-ai.md` outlines how to swap in other models, structure tools, and apply system prompts with validation hooks.  
- **Multimodal**: `references/multimodal.md` shows the payload shapes for `input_image`, `delta.images`, and `output` blocks plus how to convert base64 results into data URLs in both Python and the harness.
- **Preferred models**: the scripts default to `openai/gpt-4.1-mini`, `pydantic_agent.py` defaults to `openai/gpt-5.1-chat`, and the chat harness dropdown mirrors the table above (embedding model included as a disabled reference entry).
- **Model errors**: if you see “not a valid model ID” or similar, immediately run `scripts/list_models.py --search <fragment>` to verify the live ID and spelling before retrying. Provider prefixes sometimes change.

## Multimodal Workflow Highlights
1. For Python scripts, pass `--image path/to/file.png` (see `references/python-tools.md`) or craft message parts manually following `references/multimodal.md`. Payloads should include `{"type": "input_image", "image_url": {"url": "data:<mime>;base64,<...>"}}`.  
2. In the static harness, upload images via the attachments UI; the file is encoded to a data URL and sent as an `input_image` part alongside your text prompt. The harness also normalizes streamed responses from `delta.images`, `image_url`, or `output` blocks so generated images appear immediately.  
3. When expecting images back (e.g., Gemini 3 Pro or Gemini Flash image), parse the `image_url` blocks from the response or pick them up from the harness console logs; for Python scripts, iterate over `choice["message"]["content"]` and collect `image_url`.  
4. Always confirm the chosen model supports the modalities you need (table above) and refer to `https://openrouter.ai/docs/llms.txt` plus `https://openrouter.ai/docs/docs/overview/multimodal/image-generation.mdx` for the latest shape guidance.

## External Docs
- Models overview: https://openrouter.ai/docs/docs/overview/models  
- Docs index (load inside tasks as needed): https://openrouter.ai/docs/llms.txt  
- PydanticAI OpenRouter adapter: https://ai.pydantic.dev/models/openrouter/index.md
- Multimodal/image streaming: https://openrouter.ai/docs/docs/overview/multimodal/image-generation.mdx
