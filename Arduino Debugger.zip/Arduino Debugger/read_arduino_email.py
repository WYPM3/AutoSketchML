#!/usr/bin/env python3
"""
Read email data from Arduino serial port.
This script will read from the Arduino and display any EMAIL: messages.
"""

import serial
import serial.tools.list_ports
import time
import sys

def find_arduino_port():
    """Find the Arduino serial port."""
    ports = serial.tools.list_ports.comports()
    
    for p in ports:
        if 'usbmodem' in p.device.lower() or 'usbserial' in p.device.lower():
            return p.device
    return None

def read_arduino_email(timeout_seconds=10):
    """Read email data from Arduino."""
    arduino_port = find_arduino_port()
    
    if arduino_port is None:
        print("❌ Arduino not found. Is it plugged in?")
        return None
    
    print(f"📡 Connecting to Arduino on {arduino_port}...")
    
    try:
        arduino = serial.Serial(arduino_port, 9600, timeout=2)
        time.sleep(2)  # Wait for connection to stabilize
        
        print(f"⏳ Reading from Arduino (waiting up to {timeout_seconds} seconds for email data)...")
        print("   (Press Ctrl+C to stop)\n")
        
        emails_found = []
        prompts_seen = []
        start_time = time.time()
        
        while time.time() - start_time < timeout_seconds:
            if arduino.in_waiting > 0:
                try:
                    line = arduino.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        # Handle explicit prompt marker blocks first
                        if line == ">>>PROMPT_START<<<":
                            prompt_line = arduino.readline().decode('utf-8', errors='ignore').strip()
                            if prompt_line.upper().startswith("PROMPT:"):
                                prompt_index = prompt_line.upper().find("PROMPT:")
                                prompt_text = prompt_line[prompt_index + len("PROMPT:"):].strip() if prompt_index != -1 else prompt_line.strip()
                                prompts_seen.append(prompt_text)
                                print(f"📝 Prompt from Arduino: {prompt_text}")
                            continue

                        # Handle single-line prompt messages (no marker block)
                        if "PROMPT:" in line.upper():
                            upper_line = line.upper()
                            prompt_index = upper_line.find("PROMPT:")
                            prompt_text = line[prompt_index + len("PROMPT:"):].strip() if prompt_index != -1 else line
                            prompts_seen.append(prompt_text)
                            print(f"📝 Prompt from Arduino: {prompt_text}")
                            continue

                        if 'EMAIL:' in line.upper():
                            # Extract email
                            parts = line.split('EMAIL:')
                            if len(parts) > 1:
                                email = parts[1].strip()
                                emails_found.append(email)
                                print(f"✅ Found email: {email}")
                        else:
                            # Show other serial output for context
                            print(f"📨 Serial: {line}")
                except UnicodeDecodeError:
                    pass
        
        arduino.close()
        
        if prompts_seen:
            print(f"\n{'='*60}")
            print("📝 PROMPTS SEEN FROM ARDUINO:")
            for i, prompt in enumerate(prompts_seen, 1):
                print(f"{i}. {prompt}")

        if emails_found:
            print(f"\n{'='*60}")
            print(f"📧 SAVED EMAIL(S) FROM ARDUINO:")
            print(f"{'='*60}")
            for i, email in enumerate(emails_found, 1):
                print(f"\n{i}. {email}")
            print(f"\n{'='*60}")
            return emails_found
        else:
            print(f"\n⚠️  No email data found in serial output.")
            print("   The Arduino may need to send the email, or it may have already been sent.")
            return None
            
    except serial.SerialException as e:
        print(f"❌ Serial port error: {e}")
        return None
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted by user")
        if emails_found:
            return emails_found
        return None
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

if __name__ == "__main__":
    timeout = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    read_arduino_email(timeout)


