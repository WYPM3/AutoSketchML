
import serial, time
import serial.tools.list_ports
from agent import generate_prompt_sync

SERIAL_PORT = None  
BAUDRATE = 115200

def find_arduino_port():
    """Auto-detect Arduino serial port"""
    ports = serial.tools.list_ports.comports()
    for port in ports:
       
        if any(keyword in port.description.upper() for keyword in ['ARDUINO', 'USB', 'SERIAL']):
            return port.device
        
        if 'usbmodem' in port.device.lower() or 'usbserial' in port.device.lower():
            return port.device
    return None


def call_ai(user_prompt, context_lines=None):
    """
    user_prompt: str - user's natural prompt
    context_lines: list[str] - recent serial lines for AI to inspect
    Return: string reply
    """
    try:
       
        reply = generate_prompt_sync(user_prompt, context=context_lines)
        return reply
    except Exception as e:
        
        error_msg = f"AI Error: {str(e)}"
        print(f"Warning: {error_msg}")
        return f"DEBUG:RUNTEST:BLINK DEBUG:PINS DEBUG:LOOPRATE (AI unavailable: {error_msg})"

def send_serial_cmd(ser, cmd, wait_response=True, timeout=2.0):
    cmd_line = cmd.strip() + "\n"
    ser.write(cmd_line.encode('utf-8'))
    ser.flush()
    if not wait_response:
        return []
    t0 = time.time()
    lines = []
    while time.time() - t0 < timeout:
        if ser.in_waiting:
            line = ser.readline().decode('utf-8', errors='replace').strip()
            if line:
                lines.append(line)
               
                if any(k in line for k in ["PASS","PONG","OK:","PINS:","LOOPRATE:","VARS:","TEST:"]):
                    break
        time.sleep(0.05)
    return lines

def interactive_loop():
    port = SERIAL_PORT
    if not port:
        port = find_arduino_port()
        if not port:
            print("Error: Could not find Arduino serial port.")
            print("\nAvailable serial ports:")
            ports = serial.tools.list_ports.comports()
            if ports:
                for p in ports:
                    print(f"  - {p.device}: {p.description}")
            else:
                print("  (none found)")
            print("\nPlease:")
            print("1. Connect your Arduino")
            print("2. Set SERIAL_PORT in the script to the correct port (e.g., '/dev/tty.usbmodem14101')")
            print("   Or update find_arduino_port() to match your device")
            return
        print(f"Auto-detected Arduino port: {port}")
    
    try:
        ser = serial.Serial(port, BAUDRATE, timeout=0.1)
    except serial.SerialException as e:
        print(f"Error: Could not open serial port {port}")
        print(f"Details: {e}")
        print("\nPlease check:")
        print("1. Arduino is connected")
        print("2. No other program is using the port (close Arduino IDE)")
        print("3. Port path is correct")
        return
    time.sleep(2)  
    
    boot_lines = []
    tstart = time.time()
    while time.time() - tstart < 1.0:
        if ser.in_waiting:
            boot_lines.append(ser.readline().decode('utf-8', errors='replace').strip())
    print("Arduino boot:", boot_lines)

    while True:
        user_prompt = input("\nDescribe the problem (or 'quit'): ").strip()
        if not user_prompt:
            continue
        if user_prompt.lower() in ('q','quit','exit'):
            break

       
        ser.write(b'\n')  
        time.sleep(0.05)
        context = []
        while ser.in_waiting:
            context.append(ser.readline().decode('utf-8', errors='replace').strip())

        ai_instruction = call_ai(user_prompt, context_lines=context)
        print("\nAI suggested actions:\n", ai_instruction)

       
        cmds = []
        for token in ai_instruction.split():
            if token.startswith("DEBUG:") or token.startswith("CMD:"):
                cmds.append(token.strip().strip(','))
        if not cmds:
            print("AI did not include explicit commands. Asking AI to suggest serial commands...")
           
            ai_instruction = call_ai("Please output serial commands (one per token) to diagnose: " + user_prompt, context)
            for token in ai_instruction.split():
                if token.startswith("DEBUG:") or token.startswith("CMD:"):
                    cmds.append(token.strip().strip(','))

        print("Executing commands:", cmds)
        all_responses = []
        for c in cmds:
            lines = send_serial_cmd(ser, c, wait_response=True, timeout=2.5)
            print("->", c)
            for L in lines:
                print("   <", L)
            all_responses.extend(lines)

       
        ai_analysis = call_ai("Here are the Arduino responses:\n" + "\n".join(all_responses) + "\nPlease diagnose and suggest fixes in plain English and optionally provide corrected Arduino code.")
        print("\nAI diagnosis:\n", ai_analysis)

if __name__ == "__main__":
    interactive_loop()