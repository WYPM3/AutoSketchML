#!/usr/bin/env python3
"""
Central command-line hub to run the main Arduino Debugger workflows
from one place. Launch with:

    python3 control_center.py
"""

import traceback
from typing import Callable, List, Tuple

import RaspberryPi
import db
import monitor_arduino
import read_arduino_email
import read_arduino_sensor
import run_sensor_service
from agent import generate_arduino_code_sync, send_instruction_email
from send_arduino_email import check_env_configuration, read_email_and_prompt_from_arduino
from send_sketch import send_sketch_to_arduino


def _pause() -> None:
    input("\nPress Enter to return to the menu...")


def _action_generate_and_upload() -> None:
    """Generate Arduino code from natural language and upload it."""
    prompt = input("\nDescribe what you want the Arduino to do: ").strip()
    if not prompt:
        print("No description provided; skipping.")
        return

    print("\nGenerating code via OpenAI...")
    try:
        code = generate_arduino_code_sync(prompt)
    except Exception as exc:
        print(f"Generation failed: {exc}")
        return

    lines = code.splitlines()
    preview = "\n".join(lines[:60])
    print("\n--- Code preview (first 60 lines) ---")
    print(preview)
    if len(lines) > 60:
        print(f"... ({len(lines)} total lines)")

    confirm = input("\nUpload this sketch to Arduino now? [y/N]: ").strip().lower()
    if confirm != "y":
        print("Upload skipped.")
        return

    success = send_sketch_to_arduino(code)
    print("Upload succeeded." if success else "Upload failed.")


def _action_monitor_serial() -> None:
    """Stream all serial output from the Arduino."""
    print("\nStarting serial monitor (Ctrl+C to return)...\n")
    monitor_arduino.monitor_arduino(run_forever=True)


def _action_read_sensor_once() -> None:
    """Read and store sensor data for a short window."""
    print("\nListening for sensor data for 60 seconds...\n")
    read_arduino_sensor.read_and_store_sensor_data(run_forever=False, timeout_seconds=60)


def _action_run_sensor_supervisor() -> None:
    """Run the auto-start/stop sensor supervisor."""
    print("\nRunning sensor supervisor (Ctrl+C to stop and return)...\n")
    run_sensor_service.main()


def _action_send_instruction_email() -> None:
    """Read email/prompt from Arduino and send instructions via Resend."""
    if not check_env_configuration():
        print("\nEnvironment not ready. Please set the missing variables above.")
        return

    email, prompt = read_email_and_prompt_from_arduino(timeout_seconds=20)
    if not email or not prompt:
        print("\nCould not find both email and prompt from the Arduino.")
        return

    try:
        result = send_instruction_email(email, prompt)
        print("\nInstruction email sent successfully.")
        print(result)
    except Exception as exc:
        print(f"\nFailed to send instruction email: {exc}")


def _action_read_email_prompt_only() -> None:
    """Quickly read EMAIL:/PROMPT: messages from the Arduino."""
    try:
        timeout_raw = input("\nSeconds to listen (default 10): ").strip()
        timeout = int(timeout_raw) if timeout_raw else 10
    except ValueError:
        timeout = 10
    print(f"\nListening for EMAIL/PROMPT messages for {timeout} seconds...\n")
    read_arduino_email.read_arduino_email(timeout_seconds=timeout)


def _action_toggle_db_access() -> None:
    """Enable/disable database access for the agent."""
    current = db.is_db_access_enabled()
    db.set_db_access_enabled(not current)
    new_status = "ENABLED" if not current else "DISABLED"
    print(f"\nDatabase access is now {new_status}.")


def _action_interactive_debug() -> None:
    """Run the interactive debugging loop."""
    print("\nStarting interactive debugging session...")
    RaspberryPi.interactive_loop()


MenuItem = Tuple[str, str, Callable[[], None]]


def _menu_items() -> List[MenuItem]:
    return [
        ("1", "Generate + upload Arduino code", _action_generate_and_upload),
        ("2", "Monitor Arduino serial output", _action_monitor_serial),
        ("3", "Read/store sensor data (1 minute)", _action_read_sensor_once),
        ("4", "Run sensor supervisor (auto start/stop)", _action_run_sensor_supervisor),
        ("5", "Send instruction email from Arduino data", _action_send_instruction_email),
        ("6", "Read EMAIL/PROMPT from Arduino only", _action_read_email_prompt_only),
        ("7", "Toggle database access for AI agent", _action_toggle_db_access),
        ("8", "Interactive debug session", _action_interactive_debug),
        ("0", "Exit", lambda: None),
    ]


def main() -> None:
    print("=" * 60)
    print("Arduino Debugger Control Center")
    print("=" * 60)
    print("Run everything from one terminal. Choose an action below.\n")

    items = _menu_items()
    actions = {key: func for key, _, func in items}

    while True:
        for key, label, _ in items:
            print(f" {key}. {label}")
        choice = input("\nSelect an option: ").strip()

        if choice in ("0", "q", "quit", "exit"):
            print("Goodbye.")
            break

        action = actions.get(choice)
        if not action:
            print("Invalid choice. Please try again.\n")
            continue

        try:
            action()
        except KeyboardInterrupt:
            print("\nAction interrupted. Returning to menu.")
        except Exception as exc:
            print(f"\nUnexpected error: {exc}")
            traceback.print_exc()

        _pause()
        print()


if __name__ == "__main__":
    main()
