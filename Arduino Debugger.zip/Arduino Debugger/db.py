import os
from typing import Optional, List, Dict, Any


_DB_ACCESS_ENABLED = os.getenv("DB_ACCESS_ENABLED", "true").lower() == "true"

def set_db_access_enabled(enabled: bool) -> None:
    """Enable or disable database access for the AI agent.
    
    Args:
        enabled: True to enable database access, False to disable (kill command)
    """
    global _DB_ACCESS_ENABLED
    _DB_ACCESS_ENABLED = enabled

def is_db_access_enabled() -> bool:
    """Check if database access is currently enabled."""
    return _DB_ACCESS_ENABLED

try:
    import mysql.connector
    from mysql.connector import MySQLConnection
    MYSQL_LIB = "mysql.connector"
    pymysql = None
except ImportError:
    try:
        import pymysql
        import pymysql.cursors
        MYSQL_LIB = "pymysql"
    except ImportError:
        raise ImportError(
            "Neither mysql-connector-python nor pymysql is installed. "
            "Install one with: pip3 install mysql-connector-python "
            "or pip3 install pymysql"
        )


def _get_db_config() -> dict:
    """
    Build database configuration from environment variables.

    This is designed to work with a local MySQL/MariaDB instance that you
    also access via phpMyAdmin (typically running on localhost).

    Expected environment variables:
      - DB_HOST (default: 'localhost')
      - DB_PORT (default: 3306)
      - DB_USER (default: 'root')
      - DB_PASSWORD (no default; can be empty if your local root has no password)
      - DB_NAME (arduino.log)
    """
    return {
        "host": os.getenv("DB_HOST", "localhost"),
        "port": int(os.getenv("DB_PORT", "3306")),
        "user": os.getenv("DB_USER", "root"),
        "password": os.getenv("DB_PASSWORD", ""),
        "database": os.getenv("DB_NAME", "arduino.log"),
    }

def get_connection():
    """
    Create and return a new MySQL connection using the configured settings.

    Raises:
        ValueError: if DB_NAME is not set.
        mysql.connector.Error or pymysql.Error: if the connection fails.
    """
    config = _get_db_config()
    if not config["database"]:
        raise ValueError(
            "DB_NAME environment variable is not set. "
            "Set DB_NAME to the schema you use in phpMyAdmin."
        )
    
    if MYSQL_LIB == "mysql.connector":
        conn = mysql.connector.connect(**config)
    else:  # pymysql
        conn = pymysql.connect(**config)
    
    return conn


def test_connection() -> Optional[str]:
    """
    Simple connectivity test.

    Returns:
        str: Human-readable description of the server version if successful.
        None: If connection fails.
    """
    try:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT VERSION()")
            row = cursor.fetchone()
            if row:
                return f"Connected to MySQL server version: {row[0]}"
            return "Connected to MySQL, but could not read version."
        finally:
            conn.close()
    except Exception as exc:
        
        return None


def execute_query(query: str, params: Optional[tuple] = None) -> List[Dict[str, Any]]:
    """
    Execute a SELECT query and return results as a list of dictionaries.
    
    Args:
        query: SQL SELECT query to execute
        params: Optional tuple of parameters for parameterized queries
    
    Returns:
        List of dictionaries where each dict represents a row
    
    Raises:
        ValueError: If database access is disabled
        Exception: If query execution fails
    """
    if not _DB_ACCESS_ENABLED:
        raise ValueError(
            "Database access is currently disabled. "
            "Enable it by setting DB_ACCESS_ENABLED=true or calling set_db_access_enabled(True)"
        )
    
    conn = None
    try:
        conn = get_connection()
        if MYSQL_LIB == "mysql.connector":
            cursor = conn.cursor(dictionary=True)
        else:  # pymysql
            cursor = conn.cursor(pymysql.cursors.DictCursor)
        
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        
        results = cursor.fetchall()
        cursor.close()
        
        # Convert to list of dicts if using pymysql
        if MYSQL_LIB == "pymysql":
            return [dict(row) for row in results]
        return results
    finally:
        if conn:
            conn.close()


def get_tables() -> List[str]:
    """
    Get list of all tables in the database.
    
    Returns:
        List of table names
    
    Raises:
        ValueError: If database access is disabled
    """
    if not _DB_ACCESS_ENABLED:
        raise ValueError(
            "Database access is currently disabled. "
            "Enable it by setting DB_ACCESS_ENABLED=true or calling set_db_access_enabled(True)"
        )
    
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SHOW TABLES")
        tables = [row[0] for row in cursor.fetchall()]
        cursor.close()
        return tables
    finally:
        if conn:
            conn.close()


def get_table_schema(table_name: str) -> str:
    """
    Get the schema/structure of a specific table.
    
    Args:
        table_name: Name of the table
    
    Returns:
        String describing the table structure
    
    Raises:
        ValueError: If database access is disabled
    """
    if not _DB_ACCESS_ENABLED:
        raise ValueError(
            "Database access is currently disabled. "
            "Enable it by setting DB_ACCESS_ENABLED=true or calling set_db_access_enabled(True)"
        )
    
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(f"DESCRIBE {table_name}")
        columns = cursor.fetchall()
        cursor.close()
        
        schema_lines = [f"Table: {table_name}"]
        schema_lines.append("-" * 60)
        for col in columns:
            schema_lines.append(f"  {col[0]}: {col[1]} {col[2] if len(col) > 2 else ''}")
        
        return "\n".join(schema_lines)
    finally:
        if conn:
            conn.close()


def get_table_data(table_name: str, limit: int = 100) -> List[Dict[str, Any]]:
    """
    Get data from a specific table with optional limit.
    
    Args:
        table_name: Name of the table
        limit: Maximum number of rows to return (default: 100)
    
    Returns:
        List of dictionaries representing rows
    
    Raises:
        ValueError: If database access is disabled
    """
    if not _DB_ACCESS_ENABLED:
        raise ValueError(
            "Database access is currently disabled. "
            "Enable it by setting DB_ACCESS_ENABLED=true or calling set_db_access_enabled(True)"
        )
    
    query = f"SELECT * FROM {table_name} LIMIT {limit}"
    return execute_query(query)


def get_table_row_count(table_name: str) -> int:
    """
    Get the number of rows in a table.
    
    Args:
        table_name: Name of the table
    
    Returns:
        Number of rows
    
    Raises:
        ValueError: If database access is disabled
    """
    if not _DB_ACCESS_ENABLED:
        raise ValueError(
            "Database access is currently disabled. "
            "Enable it by setting DB_ACCESS_ENABLED=true or calling set_db_access_enabled(True)"
        )
    
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        cursor.close()
        return count
    finally:
        if conn:
            conn.close()


def fix_sensor_logs_table() -> bool:
    """
    Fix the sensor_logs table to make id AUTO_INCREMENT.
    This is a one-time setup function.
    
    Returns:
        True if successful, False otherwise
    """
    if not _DB_ACCESS_ENABLED:
        raise ValueError(
            "Database access is currently disabled. "
            "Enable it by setting DB_ACCESS_ENABLED=true or calling set_db_access_enabled(True)"
        )
    
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Check if id is already AUTO_INCREMENT
        cursor.execute("SHOW COLUMNS FROM sensor_logs WHERE Field = 'id'")
        result = cursor.fetchone()
        
        if result and 'auto_increment' in str(result).lower():
            print("✓ id field is already AUTO_INCREMENT")
            cursor.close()
            return True
        
        # Check if id is already a primary key
        cursor.execute("SHOW KEYS FROM sensor_logs WHERE Key_name = 'PRIMARY'")
        primary_key = cursor.fetchone()
        
        if not primary_key:
            # Make id PRIMARY KEY and AUTO_INCREMENT
            cursor.execute("ALTER TABLE sensor_logs MODIFY id INT(16) NOT NULL AUTO_INCREMENT PRIMARY KEY")
        else:
            # Just make it AUTO_INCREMENT (it's already a key)
            cursor.execute("ALTER TABLE sensor_logs MODIFY id INT(16) NOT NULL AUTO_INCREMENT")
        
        conn.commit()
        cursor.close()
        print("✓ Fixed sensor_logs table: id is now AUTO_INCREMENT PRIMARY KEY")
        return True
    except Exception as e:
        if conn:
            conn.rollback()
        print(f"Error fixing table: {e}")
        return False
    finally:
        if conn:
            conn.close()


def insert_sensor_log(device_id: str, sensor_type: str, sensor_value: float, 
                     units: str, battery_level: float = 100.0, 
                     signal_strength: int = 100) -> bool:
    """
    Insert a sensor reading into the sensor_logs table.
    
    Args:
        device_id: Unique identifier for the device (max 32 chars)
        sensor_type: Type of sensor (e.g., "temperature", "humidity") (max 32 chars)
        sensor_value: The sensor reading value
        units: Units of measurement (e.g., "C", "F", "%", "V") (max 16 chars)
        battery_level: Battery level percentage (default: 100.0)
        signal_strength: Signal strength (default: 100)
    
    Returns:
        True if insert was successful, False otherwise
    
    Raises:
        ValueError: If database access is disabled
    """
    if not _DB_ACCESS_ENABLED:
        raise ValueError(
            "Database access is currently disabled. "
            "Enable it by setting DB_ACCESS_ENABLED=true or calling set_db_access_enabled(True)"
        )
    
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        query = """
            INSERT INTO sensor_logs 
            (device_id, sensor_type, sensor_value, units, battery_level, signal_strength, logged_at, received_at)
            VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW())
        """
        
        cursor.execute(query, (device_id, sensor_type, sensor_value, units, 
                              battery_level, signal_strength))
        conn.commit()
        cursor.close()
        return True
    except Exception as e:
        if conn:
            conn.rollback()
        print(f"Error inserting sensor log: {e}")
        return False
    finally:
        if conn:
            conn.close()

