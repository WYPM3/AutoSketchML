# How to Connect Your Arduino

## 🔌 Physical Connection

### Step 1: Connect via USB
1. **Connect your Arduino board** to your computer using a USB cable
   - Use a USB-A to USB-B cable (for Arduino Uno/Nano)
   - Or USB-C cable (for newer Arduino boards)
   - Make sure the cable supports data transfer (not just charging)

2. **Power LED should light up** on the Arduino board
   - This confirms the board is receiving power

### Step 2: Verify Connection
The system will automatically detect your Arduino when you run the scripts.

---

## 🔍 Auto-Detection

The system automatically detects Arduino ports by looking for:
- Ports with "ARDUINO", "USB", or "SERIAL" in the description
- Ports with `usbmodem` or `usbserial` in the device name (common on macOS)

### Check Available Ports

Run this command to see all connected serial ports:

```bash
python3 -c "import serial.tools.list_ports; ports = serial.tools.list_ports.comports(); [print(f'{p.device}: {p.description}') for p in ports]"
```

### Test Arduino Detection

```bash
python3 -c "from send_sketch import find_arduino_port; port = find_arduino_port(); print(f'Arduino found at: {port}' if port else 'No Arduino detected')"
```

---

## ⚙️ Manual Port Configuration

If auto-detection doesn't work, you can manually set the port:

### Option 1: Set in Code
Edit `send_sketch.py` or `RaspberryPi.py`:

```python
SERIAL_PORT = "/dev/cu.usbmodem1101"  # Replace with your port
```

### Option 2: Pass as Parameter
When calling functions:

```python
from send_sketch import send_sketch_to_arduino

send_sketch_to_arduino(code, port="/dev/cu.usbmodem1101")
```

---

## 🖥️ Common Port Names by OS

### macOS
- `/dev/cu.usbmodemXXXX` (most common)
- `/dev/cu.usbserial-XXXX`
- `/dev/tty.usbmodemXXXX`

### Linux
- `/dev/ttyUSB0`
- `/dev/ttyACM0`

### Windows
- `COM3`, `COM4`, etc.
- Check Device Manager → Ports (COM & LPT)

---

## 🔧 Troubleshooting

### Problem: Arduino Not Detected

**Solutions:**
1. **Check USB cable** - Try a different cable
2. **Check USB port** - Try a different USB port on your computer
3. **Install drivers** (if needed):
   - macOS: Usually works automatically
   - Windows: May need CH340/CH341 drivers for some clones
   - Linux: Usually works automatically

4. **Close other programs** using the serial port:
   - Arduino IDE
   - Serial monitors
   - Other Python scripts

### Problem: Permission Denied (Linux)

```bash
sudo usermod -a -G dialout $USER
# Then log out and log back in
```

### Problem: Port Busy

**Error:** `SerialException: [Errno 16] Resource busy`

**Solutions:**
1. Close Arduino IDE
2. Close any serial monitor
3. Wait a few seconds and try again
4. Unplug and replug the USB cable

### Problem: Wrong Board Type

If upload fails, check your board type in `send_sketch.py`:

```python
ARDUINO_BOARD = "arduino:avr:uno"  # For Arduino Uno
# Other options:
# "arduino:avr:nano"  # For Arduino Nano
# "arduino:avr:mega"  # For Arduino Mega
```

---

## ✅ Verification Steps

1. **Check physical connection:**
   ```bash
   # List all ports
   python3 -c "import serial.tools.list_ports; [print(p.device) for p in serial.tools.list_ports.comports()]"
   ```

2. **Test auto-detection:**
   ```bash
   python3 -c "from send_sketch import find_arduino_port; print(find_arduino_port())"
   ```

3. **Test serial communication:**
   ```bash
   python3 RaspberryPi.py
   # Should connect and show "Arduino boot:" messages
   ```

4. **Test upload (if Arduino IDE and avrdude installed):**
   ```python
   from send_sketch import send_sketch_to_arduino
   test_code = "void setup(){pinMode(13,OUTPUT);} void loop(){digitalWrite(13,HIGH);delay(1000);digitalWrite(13,LOW);delay(1000);}"
   send_sketch_to_arduino(test_code)
   ```

---

## 📋 Quick Checklist

- [ ] Arduino connected via USB
- [ ] Power LED on Arduino is lit
- [ ] No other programs using the serial port
- [ ] Port detected by system (check with command above)
- [ ] Correct board type set in code
- [ ] `Arduino IDE` installed (for compilation)
- [ ] `avrdude` installed (for uploading code)

---

## 🚀 Next Steps

Once connected:
1. **Generate code:** Use `agent.py` to create Arduino sketches
2. **Upload code:** Use `send_sketch.py` to upload to Arduino
3. **Debug interactively:** Use `RaspberryPi.py` for real-time debugging

---

*For more help, check the main PROJECT_OVERVIEW.md file.*

