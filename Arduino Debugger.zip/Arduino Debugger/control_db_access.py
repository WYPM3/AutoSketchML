#!/usr/bin/env python3
"""
Utility script to control database access for the AI agent.

Usage:
    python3 control_db_access.py enable   # Enable database access
    python3 control_db_access.py disable  # Disable database access (kill command)
    python3 control_db_access.py status   # Check current status
    python3 control_db_access.py toggle  # Toggle between enabled/disabled
"""

import sys
import os
import db

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 control_db_access.py [enable|disable|status|toggle]")
        sys.exit(1)
    
    command = sys.argv[1].lower()
    
    if command == "enable":
        db.set_db_access_enabled(True)
        print("✅ Database access ENABLED")
        print("The AI agent can now access the database.")
    
    elif command == "disable":
        db.set_db_access_enabled(False)
        print("🔒 Database access DISABLED (kill command executed)")
        print("The AI agent cannot access the database until re-enabled.")
    
    elif command == "status":
        status = "ENABLED" if db.is_db_access_enabled() else "DISABLED"
        icon = "✅" if db.is_db_access_enabled() else "🔒"
        print(f"{icon} Database access is currently: {status}")
    
    elif command == "toggle":
        current = db.is_db_access_enabled()
        new_status = not current
        db.set_db_access_enabled(new_status)
        status = "ENABLED" if new_status else "DISABLED"
        icon = "✅" if new_status else "🔒"
        print(f"{icon} Database access toggled to: {status}")
    
    else:
        print(f"Unknown command: {command}")
        print("Usage: python3 control_db_access.py [enable|disable|status|toggle]")
        sys.exit(1)

if __name__ == "__main__":
    main()

