import serial
import serial.tools.list_ports
import subprocess
import os
import tempfile
import time
import shutil
from typing import Optional, Tuple


SERIAL_PORT = None  
BAUDRATE = 115200
ARDUINO_BOARD = "arduino:avr:uno"  

# Board configurations for avrdude
BOARD_CONFIGS = {
    "arduino:avr:uno": {
        "mcu": "atmega328p",
        "programmer": "arduino",
        "baudrate": "115200"
    },
    "arduino:avr:nano": {
        "mcu": "atmega328p",
        "programmer": "arduino",
        "baudrate": "57600"
    },
    "arduino:avr:mega": {
        "mcu": "atmega2560",
        "programmer": "wiring",
        "baudrate": "115200"
    }
}


def find_arduino_port():
    """Auto-detect Arduino serial port using pyserial"""
    ports = serial.tools.list_ports.comports()
    
    # First, look for ports with Arduino in description
    for port in ports:
        if any(keyword in port.description.upper() for keyword in ['ARDUINO', 'USB', 'SERIAL']):
            # Prefer cu.* over tty.* on macOS for uploads
            device = port.device
            if device.startswith('/dev/tty.') and 'usbmodem' in device:
                cu_device = device.replace('/dev/tty.', '/dev/cu.')
                if os.path.exists(cu_device):
                    return cu_device
            return device
    
    # Then, look for usbmodem/usbserial ports
    for port in ports:
        device = port.device
        if 'usbmodem' in device.lower() or 'usbserial' in device.lower():
            # Prefer cu.* over tty.* on macOS for uploads
            if device.startswith('/dev/tty.') and 'usbmodem' in device:
                cu_device = device.replace('/dev/tty.', '/dev/cu.')
                if os.path.exists(cu_device):
                    return cu_device
            return device
    
    return None


def get_port_info(port: str) -> Optional[dict]:
    """
    Get detailed information about a serial port using pyserial.
    
    Args:
        port: Serial port path
    
    Returns:
        dict with port information or None if port not found
    """
    ports = serial.tools.list_ports.comports()
    for p in ports:
        if p.device == port:
            return {
                "device": p.device,
                "description": p.description,
                "hwid": p.hwid,
                "vid": p.vid,
                "pid": p.pid,
                "serial_number": p.serial_number,
                "manufacturer": p.manufacturer,
                "product": p.product
            }
    return None


def save_arduino_sketch(code: str, sketch_name: str = "generated_sketch") -> str:
    """
    Save Arduino code to a temporary .ino file.
    
    Args:
        code: The Arduino code to save
        sketch_name: Name for the sketch (without .ino extension)
    
    Returns:
        str: Path to the saved .ino file
    """
    
    temp_dir = tempfile.mkdtemp(prefix="arduino_sketch_")
    sketch_dir = os.path.join(temp_dir, sketch_name)
    os.makedirs(sketch_dir, exist_ok=True)
    
    
    ino_file = os.path.join(sketch_dir, f"{sketch_name}.ino")
    with open(ino_file, 'w') as f:
        f.write(code)
    
    print(f"Sketch saved to: {ino_file}")
    return sketch_dir


def check_avrdude_installed() -> bool:
    """Check if avrdude is installed and accessible."""
    try:
        result = subprocess.run(['avrdude', '-?'], 
                              capture_output=True, text=True, timeout=5)
        if result.returncode in [0, 1]:  # avrdude returns 1 for help, which is fine
            return True
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return False


def check_arduino_ide_installed() -> Optional[str]:
    """
    Check if Arduino IDE is installed and return path to arduino-builder.
    
    Returns:
        Path to arduino-builder or None if not found
    """
    common_paths = [
        "/Applications/Arduino.app/Contents/Java/arduino-builder",
        os.path.expanduser("~/Applications/Arduino.app/Contents/Java/arduino-builder"),
        "/usr/local/bin/arduino-builder",
        "/usr/bin/arduino-builder",
    ]
    
    for path in common_paths:
        if os.path.exists(path) and os.access(path, os.X_OK):
            return path
    
    # Check if arduino-builder is in PATH
    try:
        result = subprocess.run(['which', 'arduino-builder'], 
                              capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            return result.stdout.strip()
    except:
        pass
    
    return None

def compile_with_arduino_builder(sketch_path: str, board: str = ARDUINO_BOARD) -> Tuple[bool, Optional[str]]:
    """
    Compile Arduino sketch using arduino-builder (from Arduino IDE).
    
    Args:
        sketch_path: Path to the sketch directory
        board: Arduino board type (default: arduino:avr:uno)
    
    Returns:
        Tuple of (success: bool, hex_file_path: Optional[str])
    """
    arduino_builder = check_arduino_ide_installed()
    if not arduino_builder:
        print("="*60)
        print("ERROR: Arduino IDE or arduino-builder not found")
        print("="*60)
        print("\nPlease install Arduino IDE from:")
        print("  https://www.arduino.cc/en/software")
        print("\nOr install arduino-builder separately")
        print("="*60)
        return False, None
    
    # Find Arduino IDE installation directory
    arduino_home = os.path.dirname(os.path.dirname(arduino_builder))
    hardware_path = os.path.join(arduino_home, "hardware")
    tools_path = os.path.join(arduino_home, "tools")
    
    # Create build directory
    build_dir = os.path.join(sketch_path, "build")
    os.makedirs(build_dir, exist_ok=True)
    
    try:
        compile_cmd = [
            arduino_builder,
            '-compile',
            '-logger=human',
            '-hardware', hardware_path,
            '-tools', tools_path,
            '-fqbn', board,
            '-build-path', build_dir,
            sketch_path
        ]
        
        print("\nCompiling with arduino-builder...")
        compile_result = subprocess.run(compile_cmd, capture_output=True, text=True, timeout=120)
        
        if compile_result.returncode != 0:
            print("\n" + "="*60)
            print("COMPILATION FAILED")
            print("="*60)
            if compile_result.stderr:
                print("\nError output:")
                print(compile_result.stderr)
            if compile_result.stdout:
                print("\nStandard output:")
                print(compile_result.stdout)
            print("="*60)
            return False, None
        
        print("\n✓ Compilation successful!")
        
        # Find the generated hex file
        hex_file = None
        for root, dirs, files in os.walk(build_dir):
            for file in files:
                if file.endswith('.hex'):
                    hex_file = os.path.join(root, file)
                    break
            if hex_file:
                break
        
        return True, hex_file
        
    except subprocess.TimeoutExpired:
        print("Error: Compilation timed out")
        return False, None
    except Exception as e:
        print(f"Error during compilation: {str(e)}")
        return False, None


def diagnose_upload_issue(port: str, board: str = ARDUINO_BOARD) -> None:
    """
    Print diagnostic information to help troubleshoot upload issues.
    
    Args:
        port: Serial port to diagnose
        board: Arduino board type
    """
    print("\n" + "="*60)
    print("UPLOAD DIAGNOSTICS")
    print("="*60)
    
    # Check port info
    port_info = get_port_info(port)
    if port_info:
        print(f"\nPort Information:")
        print(f"  Device: {port_info['device']}")
        print(f"  Description: {port_info.get('description', 'N/A')}")
        print(f"  Manufacturer: {port_info.get('manufacturer', 'N/A')}")
        print(f"  Product: {port_info.get('product', 'N/A')}")
    
    # Check if port is accessible
    print(f"\nPort Accessibility:")
    try:
        ser = serial.Serial(port, BAUDRATE, timeout=1)
        ser.close()
        print(f"  ✓ Port {port} is accessible")
    except Exception as e:
        print(f"  ✗ Port {port} is NOT accessible: {e}")
    
    # Check avrdude
    print(f"\nAvrdude:")
    if check_avrdude_installed():
        print("  ✓ avrdude is installed")
        try:
            result = subprocess.run(['avrdude', '-?'], capture_output=True, text=True, timeout=5)
            if 'avrdude version' in result.stdout or 'avrdude version' in result.stderr:
                version_line = [l for l in (result.stdout + result.stderr).split('\n') if 'version' in l.lower()]
                if version_line:
                    print(f"  Version: {version_line[0].strip()}")
        except:
            pass
    else:
        print("  ✗ avrdude is NOT installed")
    
    # Check board config
    board_config = BOARD_CONFIGS.get(board, BOARD_CONFIGS["arduino:avr:uno"])
    print(f"\nBoard Configuration:")
    print(f"  Board: {board}")
    print(f"  MCU: {board_config['mcu']}")
    print(f"  Programmer: {board_config['programmer']}")
    print(f"  Baudrate: {board_config['baudrate']}")
    
    print("="*60 + "\n")


def upload_with_avrdude(hex_file: str, port: Optional[str] = None, board: str = ARDUINO_BOARD) -> bool:
    """
    Upload compiled hex file to Arduino using avrdude via pyserial port management.
    
    Args:
        hex_file: Path to the compiled .hex file
        port: Serial port (auto-detected if None, managed via pyserial)
        board: Arduino board type (default: arduino:avr:uno)
    
    Returns:
        bool: True if upload successful, False otherwise
    """
    # Check if avrdude is installed
    if not check_avrdude_installed():
        print("="*60)
        print("ERROR: avrdude is not installed or not in PATH")
        print("="*60)
        print("\nTo install avrdude:")
        print("  macOS: brew install avrdude")
        print("  Linux: sudo apt-get install avrdude")
        print("  Windows: Install Arduino IDE (includes avrdude)")
        print("="*60)
        return False
    
    # Find port if not provided (using pyserial)
    if not port:
        port = find_arduino_port()
        if not port:
            print("="*60)
            print("ERROR: Could not find Arduino serial port.")
            print("="*60)
            print("\nPlease:")
            print("1. Connect your Arduino via USB")
            print("2. Check that the power LED is lit")
            print("3. Close Arduino IDE if it's open")
            print("4. Try unplugging and replugging the USB cable")
            print("\nAvailable ports (detected via pyserial):")
            ports = serial.tools.list_ports.comports()
            if ports:
                for p in ports:
                    print(f"  - {p.device}: {p.description}")
            else:
                print("  (none found)")
            print("="*60)
            return False
    
    # Get board configuration
    board_config = BOARD_CONFIGS.get(board, BOARD_CONFIGS["arduino:avr:uno"])
    
    # On macOS, prefer cu.* over tty.* for avrdude
    if port.startswith('/dev/tty.') and 'usbmodem' in port:
        cu_port = port.replace('/dev/tty.', '/dev/cu.')
        if os.path.exists(cu_port):
            port = cu_port
    
    # Verify port is accessible via pyserial and trigger reset
    ser = None
    try:
        ser = serial.Serial(port, BAUDRATE, timeout=1)
        # Trigger Arduino reset by toggling DTR
        ser.setDTR(False)
        time.sleep(0.1)
        ser.setDTR(True)
        time.sleep(0.1)
        ser.close()
        ser = None
        # Wait a bit for port to be fully released
        time.sleep(0.5)
    except serial.SerialException as e:
        if ser:
            try:
                ser.close()
            except:
                pass
        print("="*60)
        print(f"ERROR: Cannot access serial port {port} via pyserial")
        print("="*60)
        print(f"Details: {e}")
        print("\nPlease check:")
        print("1. Arduino is connected")
        print("2. No other program is using the port")
        print("3. Port path is correct")
        print("="*60)
        return False
    
    print("="*60)
    print(f"Uploading to board: {board}")
    print(f"Using port: {port} (verified via pyserial)")
    print("="*60)
    
    # Run diagnostics if upload might fail
    if not os.path.exists(hex_file):
        print(f"\nERROR: Hex file not found: {hex_file}")
        return False
    
    try:
        # Find avrdude config file - check Arduino IDE installation first
        avrdude_conf = None
        arduino_builder = check_arduino_ide_installed()
        if arduino_builder:
            # Arduino IDE includes avrdude config
            arduino_home = os.path.dirname(os.path.dirname(arduino_builder))
            ide_avrdude_conf = os.path.join(arduino_home, "hardware", "tools", "avr", "etc", "avrdude.conf")
            if os.path.exists(ide_avrdude_conf):
                avrdude_conf = ide_avrdude_conf
        
        # Fallback to system locations
        if not avrdude_conf:
            if os.path.exists('/etc/avrdude.conf'):
                avrdude_conf = '/etc/avrdude.conf'
            elif os.path.exists('/usr/local/etc/avrdude.conf'):
                avrdude_conf = '/usr/local/etc/avrdude.conf'
            elif os.path.exists(os.path.expanduser('~/avrdude.conf')):
                avrdude_conf = os.path.expanduser('~/avrdude.conf')
        
        # Build avrdude command
        upload_cmd = [
            'avrdude',
            '-p', board_config['mcu'],
            '-c', board_config['programmer'],
            '-P', port,
            '-b', board_config['baudrate'],
            '-D',  # Disable auto-erase (skip flash memory erase)
            '-U', f'flash:w:{hex_file}:i'
        ]
        
        # Add config file if found
        if avrdude_conf:
            upload_cmd.insert(1, '-C')
            upload_cmd.insert(2, avrdude_conf)
            print(f"Using avrdude config: {avrdude_conf}")
        else:
            print("Warning: No avrdude config file found, using defaults")
        
        print("\nUploading to Arduino via avrdude...")
        print("Command:", ' '.join(upload_cmd))
        print("(If upload fails, try pressing the reset button on your Arduino)")
        
        # Run avrdude with real-time output for better debugging
        upload_result = subprocess.run(upload_cmd, capture_output=True, text=True, timeout=120)
        
        if upload_result.returncode != 0:
            print("\n" + "="*60)
            print("UPLOAD FAILED")
            print("="*60)
            print(f"Return code: {upload_result.returncode}")
            
            # Print combined output (avrdude often puts errors in stdout)
            output = upload_result.stdout + upload_result.stderr
            if output:
                print("\nAvrdude output:")
                print(output)
            
            # Check for common error patterns
            output_lower = output.lower()
            if "not in sync" in output_lower or "sync" in output_lower:
                print("\n⚠️  SYNC ERROR: Arduino may not be in bootloader mode")
                print("   Try pressing the reset button right before upload")
            if "permission denied" in output_lower or "access" in output_lower:
                print("\n⚠️  PERMISSION ERROR: Port may be in use")
                print("   Close Arduino IDE and other serial monitors")
            if "device" in output_lower and "not found" in output_lower:
                print("\n⚠️  DEVICE ERROR: Check port connection")
                print("   Try unplugging and replugging the USB cable")
            
            print("\nTroubleshooting:")
            print("1. Check that Arduino is connected to the correct port")
            print("2. Close Arduino IDE and other serial monitors")
            print("3. Try pressing the reset button on Arduino right before upload")
            print("4. Unplug and replug the USB cable")
            print("5. Verify the board type matches your Arduino")
            print("6. Check that avrdude config file is correct")
            print("="*60)
            return False
        
        print("\n" + "="*60)
        print("✓ UPLOAD SUCCESSFUL!")
        print("="*60)
        return True
        
    except subprocess.TimeoutExpired:
        print("Error: Upload timed out")
        return False
    except Exception as e:
        print(f"Error during upload: {str(e)}")
        return False


def upload_with_pyserial_avrdude(sketch_path: str, port: Optional[str] = None, board: str = ARDUINO_BOARD) -> bool:
    """
    Compile and upload Arduino sketch using pyserial for port management and avrdude for upload.
    
    Args:
        sketch_path: Path to the sketch directory
        port: Serial port (auto-detected via pyserial if None)
        board: Arduino board type (default: arduino:avr:uno)
    
    Returns:
        bool: True if upload successful, False otherwise
    """
    # Compile the sketch
    compile_success, hex_file = compile_with_arduino_builder(sketch_path, board)
    if not compile_success or not hex_file:
        return False
    
    # Upload using avrdude (with pyserial port management)
    return upload_with_avrdude(hex_file, port, board)


def send_code_via_serial(code: str, port: Optional[str] = None, baudrate: int = BAUDRATE) -> bool:
    """
    Send Arduino code directly via serial port (for custom bootloaders that accept code over serial).
    
    Note: Standard Arduino bootloaders don't accept code this way. This is for custom setups.
    
    Args:
        code: The Arduino code to send
        port: Serial port (auto-detected if None)
        baudrate: Serial baud rate
    
    Returns:
        bool: True if sent successfully, False otherwise
    """
    if not port:
        port = find_arduino_port()
        if not port:
            print("Error: Could not find Arduino serial port.")
            return False
    
    try:
        ser = serial.Serial(port, baudrate, timeout=2)
        time.sleep(2)  
        
       
        lines = code.split('\n')
        print(f"Sending {len(lines)} lines of code to {port}...")
        
        for i, line in enumerate(lines, 1):
            ser.write((line + '\n').encode('utf-8'))
            ser.flush()
            time.sleep(0.01)  
        
        ser.close()
        print("Code sent successfully!")
        return True
        
    except serial.SerialException as e:
        print(f"Error: Could not open serial port {port}")
        print(f"Details: {e}")
        return False
    except Exception as e:
        print(f"Error sending code: {str(e)}")
        return False


def send_sketch_to_arduino(code: str, port: Optional[str] = None, 
                          board: str = ARDUINO_BOARD, 
                          use_pyserial: bool = True) -> bool:
    """
    Main function to send Arduino code to the Arduino board using pyserial and avrdude.
    
    Args:
        code: The Arduino code to upload
        port: Serial port (auto-detected via pyserial if None)
        board: Arduino board type (default: arduino:avr:uno)
        use_pyserial: If True, use pyserial/avrdude approach (recommended).
                     If False, attempt to send via serial (for custom bootloaders only)
    
    Returns:
        bool: True if successful, False otherwise
    """
    if not code or not code.strip():
        print("Error: No code provided")
        return False
    
    if use_pyserial:
        
        sketch_path = save_arduino_sketch(code)
        success = upload_with_pyserial_avrdude(sketch_path, port, board)
        
      
        try:
            shutil.rmtree(os.path.dirname(sketch_path))
        except:
            pass
        
        return success
    else:
        
        print("Warning: Sending code directly via serial.")
        print("This only works with custom bootloaders that accept code over serial.")
        print("For standard Arduinos, use the pyserial/avrdude method instead.")
        return send_code_via_serial(code, port)


if __name__ == "__main__":
    import sys
    
    
    if len(sys.argv) > 1 and sys.argv[1] == '--diagnose':
        port = find_arduino_port()
        if port:
            diagnose_upload_issue(port)
        else:
            print("No Arduino port detected. Please connect your Arduino.")
        sys.exit(0)
    
    # Normal operation: upload example code
    example_code = """void setup() {
  pinMode(13, OUTPUT);
}

void loop() {
  digitalWrite(13, HIGH);
  delay(1000);
  digitalWrite(13, LOW);
  delay(1000);
}"""
    
    print("Example: Sending Arduino code to board...")
    print("(Run with --diagnose flag to troubleshoot upload issues)")
    
    # Find and show detected port
    detected_port = find_arduino_port()
    if detected_port:
        print(f"Detected Arduino on port: {detected_port}")
    else:
        print("Warning: Could not auto-detect Arduino port")
    
    success = send_sketch_to_arduino(example_code)
    
    if success:
        print("\n✓ Code successfully uploaded to Arduino!")
    else:
        print("\n✗ Failed to upload code.")
        print("\nTo diagnose the issue, run:")
        print("  python3 send_sketch.py --diagnose")
        print("\nOr check:")
        print("  1. Arduino is connected")
        print("  2. Arduino IDE is installed (for compilation)")
        print("  3. avrdude is installed (for upload)")
        print("  4. Correct port and board type are set")


import os
import subprocess
import sys

def find_avrdude():
    """
    Locate AVRDUDE inside the Arduino IDE on macOS.
    Returns the path if found, else None.
    """
    possible_paths = [
        "/Applications/Arduino.app/Contents/Java/hardware/tools/avr/bin/avrdude",
        os.path.expanduser("~/Applications/Arduino.app/Contents/Java/hardware/tools/avr/bin/avrdude")
    ]
    for path in possible_paths:
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    return None

def run_avrdude(avrdude_args):
    """
    Runs AVRDUDE with the provided arguments using the IDE-bundled executable.
    
    avrdude_args: list of strings, e.g., ["-c", "arduino", "-p", "m328p", "-P", "/dev/tty.usbmodem14101", "-U", "flash:w:sketch.hex:i"]
    """
    avrdude_path = find_avrdude()
    if not avrdude_path:
        print("AVRDUDE not found inside Arduino IDE. Make sure Arduino IDE is installed.")
        sys.exit(1)

    
    os.environ['PATH'] += os.pathsep + os.path.dirname(avrdude_path)

   
    cmd = [avrdude_path] + avrdude_args
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        print("AVRDUDE failed:")
        print(result.stderr)
        return False
    print(result.stdout)
    return True


if __name__ == "__main__":
    
    example_args = [
        "-c", "arduino",           
        "-p", "m328p",            
        "-P", "/dev/tty.usbmodem14101",  
        "-b", "115200",            
        "-U", "flash:w:/path/to/sketch.hex:i"  
    ]

    run_avrdude(example_args)