# How to Send Arduino Email with Hardware Instructions

## Overview

This script reads the email address and prompt from your Arduino, generates detailed hardware construction instructions using AI, and emails them to the specified address.

## Prerequisites

1. **Arduino must be connected** and sending EMAIL: and PROMPT: messages
2. **Environment variables set** in `.env` file:
   - `RESEND_API_KEY` - Your Resend API key
   - `RESEND_FROM` - Email address to send from (must be verified in Resend)
   - `OPENAI_API_KEY` - Your OpenAI API key

## Usage

### Basic Usage

```bash
python3 send_arduino_email.py
```

### What the Script Does

1. **Checks Environment** - Verifies all required API keys are set
2. **Reads from Arduino** - Connects to Arduino and waits for:
   - `EMAIL:your-email@example.com`
   - `PROMPT:your hardware request`
3. **Generates Instructions** - Uses AI to create detailed hardware construction instructions
4. **Sends Email** - Emails the instructions to the address from Arduino

## Arduino Setup

Your Arduino should send the email and prompt on startup or when configured. The format should be:

```
EMAIL:user@example.com
PROMPT:flash the LED twice in 2 seconds
```

## Email Content

The email will include:
- **The user's prompt** - What they want to build
- **Detailed hardware instructions** including:
  - Hardware requirements list
  - Step-by-step wiring instructions
  - Pin connection diagrams
  - Code setup overview
  - Testing steps
  - Troubleshooting tips

## Troubleshooting

### Serial Port Busy

If you see "Resource busy" error:
1. Close Arduino IDE Serial Monitor
2. Close any other serial port tools
3. Wait a few seconds for Arduino to send data
4. Try again

### No Email/Prompt Found

- Make sure Arduino is connected via USB
- Verify Arduino code is sending EMAIL: and PROMPT: messages
- Check that Arduino has been running for a few seconds (it sends on startup)
- Try increasing the timeout in the script

### Email Not Sending

- Verify `RESEND_API_KEY` is correct
- Check `RESEND_FROM` email is verified in your Resend account
- Ensure `OPENAI_API_KEY` is valid
- Check your internet connection

## Example

```bash
$ python3 send_arduino_email.py

============================================================
📧 Arduino Email Instruction Sender
============================================================

============================================================
📋 Checking Environment Configuration
============================================================
✅ RESEND_API_KEY: re_abc123...
✅ RESEND_FROM: arduino@example.com
✅ OPENAI_API_KEY: sk-proj-...
============================================================

============================================================
📡 Reading from Arduino...
============================================================
📡 Connecting to Arduino on /dev/cu.usbmodem113401...
⏳ Reading from Arduino (waiting up to 20 seconds for email and prompt)...
✅ Found email: user@example.com
✅ Found prompt: flash the LED twice in 2 seconds

============================================================
📝 Summary
============================================================
Email: user@example.com
Prompt: flash the LED twice in 2 seconds
============================================================

============================================================
🤖 Generating Hardware Instructions...
============================================================
This may take a moment as we generate detailed instructions...

============================================================
✅ SUCCESS!
============================================================
📧 Email sent successfully to: user@example.com
📝 Prompt: flash the LED twice in 2 seconds

📨 Email includes:
   - The user's prompt
   - Detailed step-by-step hardware construction instructions
   - Pin connections and wiring diagrams
   - Code setup instructions
============================================================
```

## Manual Override

If you need to send an email manually without reading from Arduino, you can modify the script or use the agent directly:

```python
from agent import send_instruction_email

result = send_instruction_email(
    user_email="user@example.com",
    user_prompt="flash the LED twice in 2 seconds"
)
print(result)
```

