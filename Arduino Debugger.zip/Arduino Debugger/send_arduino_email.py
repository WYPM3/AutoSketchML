#!/usr/bin/env python3
"""
Read email and prompt from Arduino, generate detailed hardware instructions,
and send them via email using Resend API.
"""

import serial
import serial.tools.list_ports
import time
import sys
import os
from agent import send_instruction_email
from typing import Optional, Tuple

def find_arduino_port():
    """Find the Arduino serial port."""
    ports = serial.tools.list_ports.comports()
    
    for p in ports:
        if 'usbmodem' in p.device.lower() or 'usbserial' in p.device.lower():
            return p.device
    return None

def read_email_and_prompt_from_arduino(timeout_seconds=15, retry_count=3) -> Tuple[Optional[str], Optional[str]]:
    """
    Read email and prompt from Arduino serial port.
    
    Returns:
        Tuple of (email, prompt) or (None, None) if not found
    """
    arduino_port = find_arduino_port()
    
    if arduino_port is None:
        print("❌ Arduino not found. Is it plugged in?")
        return None, None
    
    print(f"📡 Connecting to Arduino on {arduino_port}...")
    
    # Try to open port with retries
    arduino = None
    for attempt in range(retry_count):
        try:
            arduino = serial.Serial(arduino_port, 9600, timeout=2)
            break
        except serial.SerialException as e:
            if "Resource busy" in str(e) or "could not open port" in str(e):
                if attempt < retry_count - 1:
                    print(f"⚠️  Port busy, waiting 3 seconds before retry {attempt + 2}/{retry_count}...")
                    time.sleep(3)
                else:
                    print(f"❌ Serial port is busy after {retry_count} attempts!")
                    print(f"\n💡 Please close:")
                    print(f"   - Arduino IDE Serial Monitor")
                    print(f"   - Any other serial port monitors")
                    print(f"   - Other Python scripts using the port")
                    print(f"\nAlternatively, the Arduino will send EMAIL: and PROMPT: messages")
                    print(f"automatically on startup. You can also use read_arduino_email.py to")
                    print(f"capture them first, then run this script with manual input.")
                    return None, None
            else:
                raise
    
    if arduino is None:
        return None, None
    
    try:
        time.sleep(2)  # Wait for connection to stabilize
        
        print(f"⏳ Reading from Arduino (waiting up to {timeout_seconds} seconds for email and prompt)...")
        print("   (Press Ctrl+C to stop)\n")
        
        email_found = None
        prompt_found = None
        start_time = time.time()
        
        while time.time() - start_time < timeout_seconds:
            if arduino.in_waiting > 0:
                try:
                    line = arduino.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        # Handle EMAIL: messages
                        if 'EMAIL:' in line.upper():
                            parts = line.split('EMAIL:')
                            if len(parts) > 1:
                                email_found = parts[1].strip()
                                print(f"✅ Found email: {email_found}")
                        
                        # Handle PROMPT: messages
                        elif "PROMPT:" in line.upper():
                            upper_line = line.upper()
                            prompt_index = upper_line.find("PROMPT:")
                            prompt_found = line[prompt_index + len("PROMPT:"):].strip() if prompt_index != -1 else line
                            print(f"✅ Found prompt: {prompt_found}")
                        
                        # Stop if we have both
                        if email_found and prompt_found:
                            break
                except UnicodeDecodeError:
                    pass
        
        arduino.close()
        
        return email_found, prompt_found
            
    except serial.SerialException as e:
        print(f"❌ Serial port error: {e}")
        return None, None
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted by user")
        return email_found, prompt_found
    except Exception as e:
        print(f"❌ Error: {e}")
        return None, None

def check_env_configuration():
    """Check if required environment variables are set."""
    print("\n" + "="*60)
    print("📋 Checking Environment Configuration")
    print("="*60)
    
    required_vars = {
        'RESEND_API_KEY': 'Resend API key for sending emails',
        'RESEND_FROM': 'Email address to send from',
        'OPENAI_API_KEY': 'OpenAI API key for generating instructions'
    }
    
    missing = []
    for var, description in required_vars.items():
        value = os.getenv(var)
        if value:
            # Mask the API key for security
            if 'KEY' in var:
                masked = value[:8] + "..." + value[-4:] if len(value) > 12 else "***"
                print(f"✅ {var}: {masked}")
            else:
                print(f"✅ {var}: {value}")
        else:
            print(f"❌ {var}: NOT SET - {description}")
            missing.append(var)
    
    print("="*60)
    
    if missing:
        print(f"\n⚠️  Missing environment variables: {', '.join(missing)}")
        print("   Please set them in your .env file or environment.")
        return False
    
    return True

def main():
    """Main function to read Arduino data and send email."""
    print("="*60)
    print("📧 Arduino Email Instruction Sender")
    print("="*60)
    
    # Check environment configuration
    if not check_env_configuration():
        print("\n❌ Cannot proceed without required environment variables.")
        sys.exit(1)
    
    # Read email and prompt from Arduino
    print("\n" + "="*60)
    print("📡 Reading from Arduino...")
    print("="*60)
    
    email, prompt = read_email_and_prompt_from_arduino(timeout_seconds=20)
    
    if not email:
        print("\n❌ No email address found from Arduino.")
        print("   Please make sure the Arduino has sent an EMAIL: message.")
        sys.exit(1)
    
    if not prompt:
        print("\n❌ No prompt found from Arduino.")
        print("   Please make sure the Arduino has sent a PROMPT: message.")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("📝 Summary")
    print("="*60)
    print(f"Email: {email}")
    print(f"Prompt: {prompt}")
    print("="*60)
    
    # Generate and send email
    print("\n" + "="*60)
    print("🤖 Generating Hardware Instructions...")
    print("="*60)
    print("This may take a moment as we generate detailed instructions...")
    
    try:
        result = send_instruction_email(
            user_email=email,
            user_prompt=prompt,
            context=None
        )
        
        print("\n" + "="*60)
        print("✅ SUCCESS!")
        print("="*60)
        print(f"📧 Email sent successfully to: {email}")
        print(f"📝 Prompt: {prompt}")
        print(f"\n📨 Email includes:")
        print("   - The user's prompt")
        print("   - Detailed step-by-step hardware construction instructions")
        print("   - Pin connections and wiring diagrams")
        print("   - Code setup instructions")
        print("="*60)
        print(f"\nResult: {result}")
        
    except ValueError as e:
        print(f"\n❌ Configuration Error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error sending email: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()

