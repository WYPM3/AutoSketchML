#!/usr/bin/env python3
"""
Read sensor data from Arduino serial port and insert into database.
This script continuously monitors the Arduino serial port for SENSOR: messages
and inserts them into the sensor_logs table.
"""

import serial
import serial.tools.list_ports
import time
import sys
import db
from datetime import datetime

def find_arduino_port():
    """Find the Arduino serial port."""
    ports = serial.tools.list_ports.comports()
    
    for p in ports:
        if 'usbmodem' in p.device.lower() or 'usbserial' in p.device.lower():
            return p.device
    return None

def parse_sensor_data(line: str) -> dict:
    """
    Parse a SENSOR: line from Arduino.
    Format: SENSOR:device_id|sensor_type|sensor_value|units|battery_level|signal_strength
    
    Returns:
        Dictionary with parsed sensor data, or None if parsing fails
    """
    if not line.upper().startswith("SENSOR:"):
        return None
    
    try:
        # Remove "SENSOR:" prefix
        data_part = line[7:].strip()
        parts = data_part.split('|')
        
        if len(parts) != 6:
            print(f"⚠️  Invalid sensor data format (expected 6 parts, got {len(parts)}): {line}")
            return None
        
        return {
            'device_id': parts[0].strip(),
            'sensor_type': parts[1].strip(),
            'sensor_value': float(parts[2].strip()),
            'units': parts[3].strip(),
            'battery_level': float(parts[4].strip()),
            'signal_strength': int(parts[5].strip())
        }
    except (ValueError, IndexError) as e:
        print(f"⚠️  Error parsing sensor data: {e} - Line: {line}")
        return None

def read_and_store_sensor_data(run_forever=True, timeout_seconds=60):
    """
    Read sensor data from Arduino and store in database.
    
    Args:
        run_forever: If True, runs continuously. If False, runs for timeout_seconds.
        timeout_seconds: Maximum time to run if run_forever is False.
    """
    arduino_port = find_arduino_port()
    
    if arduino_port is None:
        print("❌ Arduino not found. Is it plugged in?")
        return None
    
    print(f"📡 Connecting to Arduino on {arduino_port}...")
    
    # Check database access
    if not db.is_db_access_enabled():
        print("❌ Database access is disabled. Enable it with:")
        print("   python3 control_db_access.py enable")
        return None
    
    try:
        arduino = serial.Serial(arduino_port, 9600, timeout=2)
        time.sleep(2)  # Wait for connection to stabilize
        
        print(f"✅ Connected to Arduino")
        print(f"📊 Listening for sensor data...")
        if run_forever:
            print("   (Press Ctrl+C to stop)\n")
        else:
            print(f"   (Will run for {timeout_seconds} seconds)\n")
        
        sensor_count = 0
        start_time = time.time()
        
        while True:
            if not run_forever and (time.time() - start_time) > timeout_seconds:
                break
            
            if arduino.in_waiting > 0:
                try:
                    line = arduino.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        sensor_data = parse_sensor_data(line)
                        
                        if sensor_data:
                            # Insert into database
                            success = db.insert_sensor_log(
                                device_id=sensor_data['device_id'],
                                sensor_type=sensor_data['sensor_type'],
                                sensor_value=sensor_data['sensor_value'],
                                units=sensor_data['units'],
                                battery_level=sensor_data['battery_level'],
                                signal_strength=sensor_data['signal_strength']
                            )
                            
                            if success:
                                sensor_count += 1
                                print(f"✅ [{sensor_count}] Stored: {sensor_data['device_id']} | "
                                      f"{sensor_data['sensor_type']} = {sensor_data['sensor_value']} {sensor_data['units']} | "
                                      f"Battery: {sensor_data['battery_level']}% | "
                                      f"Signal: {sensor_data['signal_strength']}")
                            else:
                                print(f"❌ Failed to store sensor data: {sensor_data}")
                        else:
                            # Show other serial output for context (but don't process)
                            if line and not line.upper().startswith("EMAIL:") and not line.upper().startswith("PROMPT:"):
                                print(f"📨 Serial: {line}")
                except UnicodeDecodeError:
                    pass
                except Exception as e:
                    print(f"⚠️  Error processing line: {e}")
            
            time.sleep(0.1)  # Small delay to prevent CPU spinning
        
        arduino.close()
        
        print(f"\n{'='*60}")
        print(f"📊 Summary: Stored {sensor_count} sensor reading(s) in database")
        print(f"{'='*60}")
        return sensor_count
            
    except serial.SerialException as e:
        print(f"❌ Serial port error: {e}")
        return None
    except KeyboardInterrupt:
        print(f"\n\n⚠️  Interrupted by user")
        print(f"📊 Stored {sensor_count} sensor reading(s) before interruption")
        return sensor_count
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

if __name__ == "__main__":
    # Check command line arguments
    if len(sys.argv) > 1:
        if sys.argv[1] == "--once" or sys.argv[1] == "-o":
            # Run once for a limited time
            timeout = int(sys.argv[2]) if len(sys.argv) > 2 else 60
            read_and_store_sensor_data(run_forever=False, timeout_seconds=timeout)
        elif sys.argv[1] == "--help" or sys.argv[1] == "-h":
            print("Usage:")
            print("  python3 read_arduino_sensor.py          # Run continuously")
            print("  python3 read_arduino_sensor.py --once    # Run for 60 seconds")
            print("  python3 read_arduino_sensor.py --once 120 # Run for 120 seconds")
        else:
            print(f"Unknown argument: {sys.argv[1]}")
            print("Use --help for usage information")
    else:
        # Run forever by default
        read_and_store_sensor_data(run_forever=True)

