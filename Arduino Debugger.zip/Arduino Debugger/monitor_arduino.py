#!/usr/bin/env python3
"""
Monitor and display all data coming from Arduino serial port.
This script shows raw serial output without parsing, useful for debugging.
"""

import serial
import serial.tools.list_ports
import time
import sys

def find_arduino_port():
    """Find the Arduino serial port."""
    ports = serial.tools.list_ports.comports()
    
    for p in ports:
        if 'usbmodem' in p.device.lower() or 'usbserial' in p.device.lower():
            return p.device
    return None

def monitor_arduino(run_forever=True, timeout_seconds=30):
    """
    Monitor Arduino serial output and display all data.
    
    Args:
        run_forever: If True, runs continuously. If False, runs for timeout_seconds.
        timeout_seconds: Maximum time to run if run_forever is False.
    """
    arduino_port = find_arduino_port()
    
    if arduino_port is None:
        print("❌ Arduino not found. Is it plugged in?")
        return
    
    print(f"📡 Connecting to Arduino on {arduino_port}...")
    print(f"⚙️  Baud rate: 9600")
    
    try:
        # Try to open the port
        try:
            arduino = serial.Serial(arduino_port, 9600, timeout=2)
        except serial.SerialException as e:
            if "Resource busy" in str(e) or "could not open port" in str(e):
                print(f"❌ Port is busy! Another program may be using it.")
                print(f"\n💡 Please close:")
                print(f"   - Arduino IDE Serial Monitor")
                print(f"   - Any other serial port monitors")
                print(f"   - Other Python scripts using the port")
                print(f"\nThen try again.")
                return
            else:
                raise
        
        time.sleep(2)  # Wait for connection to stabilize
        
        print(f"✅ Connected to Arduino")
        print(f"📊 Monitoring serial output...")
        if run_forever:
            print("   (Press Ctrl+C to stop)\n")
        else:
            print(f"   (Will run for {timeout_seconds} seconds)\n")
        print("=" * 60)
        
        line_count = 0
        start_time = time.time()
        
        while True:
            if not run_forever and (time.time() - start_time) > timeout_seconds:
                break
            
            if arduino.in_waiting > 0:
                try:
                    line = arduino.readline().decode('utf-8', errors='replace').strip()
                    if line:
                        line_count += 1
                        timestamp = time.strftime("%H:%M:%S")
                        
                        # Color code different message types
                        if line.upper().startswith("SENSOR:"):
                            print(f"[{timestamp}] 🟢 SENSOR: {line[7:]}")
                        elif line.upper().startswith("EMAIL:"):
                            print(f"[{timestamp}] 📧 EMAIL: {line[6:]}")
                        elif line.upper().startswith("PROMPT:"):
                            print(f"[{timestamp}] 📝 PROMPT: {line[7:]}")
                        else:
                            print(f"[{timestamp}] 📨 RAW: {line}")
                        
                        # Show raw bytes for debugging
                        if len(line) < 100:  # Only for short lines
                            raw_bytes = arduino.readline() if arduino.in_waiting else b''
                            if raw_bytes:
                                print(f"         (raw bytes: {raw_bytes.hex()})")
                            
                except UnicodeDecodeError as e:
                    print(f"⚠️  Unicode decode error: {e}")
                except Exception as e:
                    print(f"⚠️  Error reading line: {e}")
            
            time.sleep(0.05)  # Small delay to prevent CPU spinning
        
        arduino.close()
        
        print("=" * 60)
        print(f"📊 Summary: Received {line_count} line(s)")
        print("=" * 60)
            
    except serial.SerialException as e:
        print(f"❌ Serial port error: {e}")
    except KeyboardInterrupt:
        print(f"\n\n⚠️  Interrupted by user")
        print(f"📊 Received {line_count} line(s) before interruption")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    # Check command line arguments
    if len(sys.argv) > 1:
        if sys.argv[1] == "--once" or sys.argv[1] == "-o":
            # Run once for a limited time
            timeout = int(sys.argv[2]) if len(sys.argv) > 2 else 30
            monitor_arduino(run_forever=False, timeout_seconds=timeout)
        elif sys.argv[1] == "--help" or sys.argv[1] == "-h":
            print("Usage:")
            print("  python3 monitor_arduino.py          # Run continuously")
            print("  python3 monitor_arduino.py --once    # Run for 30 seconds")
            print("  python3 monitor_arduino.py --once 60 # Run for 60 seconds")
        else:
            print(f"Unknown argument: {sys.argv[1]}")
            print("Use --help for usage information")
    else:
        # Run forever by default
        monitor_arduino(run_forever=True)

