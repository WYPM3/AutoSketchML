#!/usr/bin/env python3
"""
Auto-start/stop the Arduino sensor reader based on whether the Arduino is online.

Behavior:
 - If an Arduino serial port is detected, start `read_arduino_sensor.py`.
 - If no Arduino is detected, ensure the sensor reader is not running.
 - If the reader crashes or exits, restart it when the Arduino is present.

Usage:
    python3 run_sensor_service.py

Press Ctrl+C to stop the supervisor.
"""

import subprocess
import time
import serial.tools.list_ports
import signal
import sys

CHECK_INTERVAL_SEC = 5  # How often to check for Arduino presence


def find_arduino_port():
    """Auto-detect Arduino serial port."""
    ports = serial.tools.list_ports.comports()
    for p in ports:
        if "usbmodem" in p.device.lower() or "usbserial" in p.device.lower():
            return p.device
    return None


def stop_process(proc: subprocess.Popen):
    """Terminate a subprocess gracefully."""
    if proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


def main():
    print("=" * 60)
    print("🔌 Arduino Sensor Service Supervisor")
    print("=" * 60)

    reader_proc = None

    try:
        while True:
            port = find_arduino_port()

            if port:
                # Arduino present
                if reader_proc is None or reader_proc.poll() is not None:
                    print(f"✅ Arduino detected at {port}. Starting sensor reader...")
                    reader_proc = subprocess.Popen(
                        [sys.executable, "read_arduino_sensor.py"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                    )
                else:
                    # Reader already running; optionally log a heartbeat
                    pass
            else:
                # Arduino not present
                if reader_proc and reader_proc.poll() is None:
                    print("⚠️  Arduino not detected. Stopping sensor reader...")
                    stop_process(reader_proc)
                reader_proc = None

            time.sleep(CHECK_INTERVAL_SEC)
    except KeyboardInterrupt:
        print("\nStopping supervisor...")
    finally:
        if reader_proc and reader_proc.poll() is None:
            stop_process(reader_proc)
        print("Exited cleanly.")


if __name__ == "__main__":
    main()

