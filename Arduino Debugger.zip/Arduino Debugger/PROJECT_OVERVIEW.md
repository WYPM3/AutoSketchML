# Arduino Debugger - Project Overview

## 🎯 Project Purpose

An AI-powered Arduino development and debugging system that combines:
- **AI Code Generation**: Uses OpenAI GPT-4o-mini to generate complete Arduino sketches from natural language descriptions
- **Automated Upload**: Compiles and uploads generated code directly to Arduino boards
- **Interactive Debugging**: Real-time serial communication for debugging Arduino programs with AI assistance

## 📁 Project Structure

```
Arduino Debugger/
├── agent.py              # AI agent for code generation and debugging
├── send_sketch.py        # Arduino code upload and compilation utilities
├── RaspberryPi.py        # Interactive debugging interface with serial communication
├── requirements.txt      # Python dependencies
└── tools/                # (Empty - reserved for future tools)
```

## Core Components

### 1. `agent.py` - AI Code Generation Engine

**Purpose**: Generates Arduino code using OpenAI's GPT-4o-mini model

**Key Features**:
- Lazy initialization of AI agent (only creates when needed)
- Supports async and sync interfaces
- Context-aware code generation (can use serial output for debugging)
- Hardware component awareness (LEDs, displays, motors, etc.)

**Main Functions**:
- `generate_arduino_code(user_input, context)` - Generates complete Arduino sketches
- `generate_prompt(user_input, context)` - General AI assistance for Arduino questions
- `generate_arduino_code_sync()` / `generate_prompt_sync()` - Synchronous wrappers

**Supported Hardware Components**:
- LED lights
- Fan motor
- RGB lighting
- 4-digit display
- 1-digit display
- LCD 1602 module display

**Configuration**:
- Requires `OPENAI_API_KEY` environment variable
- Uses `openai:gpt-4o-mini` model
- System prompt optimized for Arduino code generation

---

### 2. `send_sketch.py` - Arduino Upload System

**Purpose**: Handles compilation and uploading of Arduino code to physical boards

**Key Features**:
- Auto-detection of Arduino serial ports using `pyserial`
- Compilation using `arduino-builder` (from Arduino IDE)
- Upload using `avrdude` with pyserial port management
- Support for multiple Arduino board types (default: Arduino Uno)
- Temporary file management for sketches

**Main Functions**:
- `find_arduino_port()` - Auto-detects connected Arduino using pyserial
- `get_port_info(port)` - Gets detailed port information via pyserial
- `save_arduino_sketch(code, sketch_name)` - Saves code to temporary .ino file
- `compile_with_arduino_builder(sketch_path, board)` - Compiles sketch using arduino-builder
- `upload_with_avrdude(hex_file, port, board)` - Uploads compiled hex via avrdude
- `upload_with_pyserial_avrdude(sketch_path, port, board)` - Complete compile and upload workflow
- `send_sketch_to_arduino(code, port, board)` - Main entry point for uploading code

**Requirements**:
- `pyserial` must be installed (Python package)
- Arduino IDE installed (for `arduino-builder` compilation tool)
- `avrdude` must be installed and in PATH (for uploading)
- Arduino board connected via USB
- Appropriate board type specified (default: `arduino:avr:uno`)

**Configuration**:
- Default baudrate: 115200
- Default board: `arduino:avr:uno`
- Serial port auto-detection via pyserial or manual specification
- Board configurations for avrdude (Uno, Nano, Mega supported)

---

### 3. `RaspberryPi.py` - Interactive Debugging Interface

**Purpose**: Interactive command-line interface for debugging Arduino programs

**Key Features**:
- Real-time serial communication with Arduino
- AI-assisted debugging suggestions
- Command parsing and execution
- Context-aware AI responses based on serial output

**Main Functions**:
- `find_arduino_port()` - Auto-detects Arduino serial port
- `call_ai(user_prompt, context_lines)` - Gets AI suggestions (currently mocked)
- `send_serial_cmd(ser, cmd, wait_response, timeout)` - Sends commands and reads responses
- `interactive_loop()` - Main interactive debugging session

**Workflow**:
1. User describes problem in natural language
2. System reads current serial output for context
3. AI suggests debugging commands (DEBUG:*, CMD:*)
4. Commands are executed on Arduino
5. AI analyzes responses and suggests fixes/code corrections

**Supported Commands** (from AI suggestions):
- `DEBUG:RUNTEST:BLINK` - Test LED blinking
- `DEBUG:PINS` - Check pin states
- `DEBUG:LOOPRATE` - Measure loop execution rate
- `DEBUG:VARS` - Inspect variable values
- Custom `CMD:*` commands

**Configuration**:
- Default baudrate: 115200
- Serial port auto-detection
- Timeout: 2.0 seconds for command responses

---

## 🔄 Typical Workflow

### Code Generation & Upload Flow:
```
1. User describes desired Arduino project
   ↓
2. agent.py generates complete Arduino code
   ↓
3. send_sketch.py compiles and uploads to Arduino
   ↓
4. Arduino runs the code
```

### Debugging Flow:
```
1. User reports issue with Arduino program
   ↓
2. RaspberryPi.py reads serial output for context
   ↓
3. AI suggests debugging commands
   ↓
4. Commands executed on Arduino via serial
   ↓
5. AI analyzes responses and suggests fixes
   ↓
6. (Optional) Generate corrected code via agent.py
```

---

## 📦 Dependencies

**Python Packages** (from `requirements.txt`):
- `pyserial>=3.5` - Serial communication with Arduino
- `pydantic-ai>=0.0.1` - AI agent framework
- `openai>=1.0.0` - OpenAI API client

**External Tools**:
- `Arduino IDE` - For compilation (provides `arduino-builder`)
  - Install from: https://www.arduino.cc/en/software
- `avrdude` - For uploading compiled sketches
  - macOS: `brew install avrdude`
  - Linux: `sudo apt-get install avrdude`
  - Windows: Included with Arduino IDE

**Environment Variables**:
- `OPENAI_API_KEY` - Required for AI code generation

---

## 🚀 Getting Started

### 1. Install Dependencies
```bash
pip3 install -r requirements.txt
```

### 2. Install Arduino IDE and avrdude
```bash
# Install Arduino IDE from: https://www.arduino.cc/en/software

# Install avrdude
# macOS
brew install avrdude

# Linux
sudo apt-get install avrdude

# Windows: avrdude is included with Arduino IDE
```

### 3. Set OpenAI API Key
```bash
export OPENAI_API_KEY='your-api-key-here'
```

### 4. Connect Arduino
- Connect Arduino board via USB
- Port will be auto-detected, or set manually in scripts

### 5. Use the System

**Generate and Upload Code**:
```python
from agent import generate_arduino_code_sync
from send_sketch import send_sketch_to_arduino

# Generate code
code = generate_arduino_code_sync("Blink an LED on pin 13")

# Upload to Arduino
send_sketch_to_arduino(code)
```

**Interactive Debugging**:
```bash
python3 RaspberryPi.py
```

---

## 🎨 Design Patterns

1. **Lazy Initialization**: AI agent only created when needed (avoids errors without API key)
2. **Async/Sync Wrappers**: Both async and sync interfaces for flexibility
3. **Auto-Detection**: Serial ports and Arduino boards detected automatically
4. **Context-Aware AI**: Serial output used as context for better debugging suggestions
5. **Temporary File Management**: Sketches saved to temp directories, cleaned up after upload

---

## 🔍 Current Status & Notes

### Working Features:
✅ AI code generation with hardware awareness  
✅ Arduino sketch upload via pyserial/avrdude  
✅ Serial port auto-detection using pyserial  
✅ Interactive debugging interface structure  
✅ Context-aware AI prompts  
✅ Port management and verification via pyserial  

### Areas for Enhancement:
- `RaspberryPi.py` has mocked AI function (`call_ai`) - needs integration with `agent.py`
- Error handling could be more robust
- No GUI interface (command-line only)
- Limited hardware component definitions
- No code validation before upload

### Integration Opportunities:
- Connect `RaspberryPi.py`'s `call_ai()` to use `agent.py` functions
- Add code validation/syntax checking before upload
- Implement hardware component detection
- Add logging and error recovery

---

## 🛠️ Technical Details

**Python Version**: 3.9+  
**Serial Communication**: 115200 baud  
**Default Board**: Arduino Uno (ATmega328P)  
**AI Model**: OpenAI GPT-4o-mini  
**File Format**: Arduino .ino sketches  

---

## 📝 Example Use Cases

1. **Quick Prototyping**: "Make an LED blink" → Code generated and uploaded in seconds
2. **Hardware Integration**: "Control RGB LED with button" → Complete code with pin definitions
3. **Debugging**: "My sensor readings are wrong" → AI suggests diagnostic commands
4. **Learning**: "How do I use a 4-digit display?" → AI explains and generates example code

---

## 🔐 Security Notes

- OpenAI API key stored in environment variable (not hardcoded)
- Temporary sketch files cleaned up after upload
- Serial port access requires appropriate permissions

---

## 📚 Future Enhancements

- [ ] GUI interface for easier interaction
- [ ] Support for more Arduino board types
- [ ] Hardware component auto-detection
- [ ] Code syntax validation
- [ ] Version control for generated sketches
- [ ] Real-time serial monitoring dashboard
- [ ] Integration with Arduino libraries database
- [ ] Multi-board support
- [ ] Cloud-based code storage

---

*Last Updated: 2025*

