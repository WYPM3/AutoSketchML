# Arduino Uno R3 Super Starter Kit — Tooling Manifest

Curated list of the typical hardware/tools in an Uno R3 “super starter” kit so you can quickly reference what’s available when composing prompts or wiring plans.

## Core & I/O
- Arduino Uno R3 board (ATmega328P, 5V logic, 14×DIO, 6×PWM, 6×analog)
- USB A–B cable
- Full-size breadboard (≈400–830 tie-points)
- Male–male and male–female jumper wires (assorted lengths)

## Output / Actuators
- 16×2 LCD (HD44780-compatible) + contrast potentiometer
- Passive buzzer and active buzzer
- LEDs (assorted colors) + current-limiting resistors
- Servo motor (micro 9g)
- DC hobby motor + motor driver (e.g., L293D or ULN2003)
- 7-segment display (common anode/cathode)
- Relay module (single-channel, low-level trigger)

## Input / Sensors
- Push-buttons and tactile switches
- Potentiometers (rotary)
- Light-dependent resistor (LDR/photocell) + divider resistor
- Temperature sensor (e.g., TMP36/LM35)
- Ultrasonic distance sensor (HC-SR04)
- IR receiver + IR remote
- Tilt switch / vibration sensor
- Flame sensor (IR photodiode-based)
- Sound sensor (microphone module)
- Joystick module (X/Y axes + push switch)

## Communication / Timing
- IR transmitter LED
- RTC module (e.g., DS1307/DS3231) — sometimes included

## Power & Protection
- 9V battery clip or barrel jack adapter
- Assorted resistors (commonly 220 Ω, 330 Ω, 1 kΩ, 4.7 kΩ, 10 kΩ, 100 kΩ)
- Assorted ceramic electrolytic capacitors (e.g., 10 nF, 100 nF, 1 µF, 10 µF, 100 µF)
- Diodes (e.g., 1N4007), small signal transistors (e.g., 2N2222/2N3904)

## Prototyping Aids
- Breadboard power rails and jumper kits
- Dupont connectors and headers
- Resistor color code card / quick reference
- Small screwdriver for terminal modules and LCD contrast pot

## Commonly Used Modules (vary by kit brand)
- Keypad matrix (3×4 or 4×4)
- RGB LED (common anode/cathode)
- Stepper motor + driver (e.g., 28BYJ-48 + ULN2003)
- I²C backpack for 16×2 LCD (PCF8574) — if present, reduces pin count to SDA/SCL

## Usage Notes
- LCD: use 10 kΩ pot on V0 for contrast; backlight via 220–1 kΩ resistor if not on driver board.
- Servos: power from 5V rail; avoid drawing servo current from Uno’s 5V regulator when USB-powered if torque loads spike.
- Motors/relays: use driver (L293D/ULN2003/relay board) and a diode for flyback if discrete.
- Sensors: LDR uses a voltage divider; TMP36 outputs 10 mV/°C with 500 mV offset; HC-SR04 uses TRIG/ECHO with 5V logic.

> If your kit has variants (e.g., no RTC, different motor driver), add them here so prompts stay accurate.
