from pydantic_ai import Agent, RunContext
import json
import os
from typing import Optional
import db
import resend


try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  


tools = [
    {
        "name": "led_lights",
        "description": "Control LED lights on the Arduino",
        "type": "hardware"
    },
    {
        "name": "fan_motor",
        "description": "Control fan motor on the Arduino",
        "type": "hardware"
    },
    {
        "name": "rgb_lighting",
        "description": "Control RGB lighting on the Arduino",
        "type": "hardware"
    },
    {
        "name": "4_digit_display",
        "description": "Control 4-digit display module on the Arduino",
        "type": "hardware"
    },
    {
        "name": "1_digit_display",
        "description": "Control 1-digit display module on the Arduino",
        "type": "hardware"
    },
    {
        "name": "lcd_1602_module_display",
        "description": "Control LCD 1602 module display on the Arduino",
        "type": "hardware"
    }
]


OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
if not OPENAI_API_KEY:
    print("Warning: OPENAI_API_KEY environment variable not set.")
    print("Please set it using: export OPENAI_API_KEY='your-api-key-here'")

RESEND_API_KEY = os.getenv("RESEND_API_KEY")
RESEND_FROM = os.getenv("RESEND_FROM", "onboarding@resend.dev")

# Configure Resend once. If the key is missing we fail later on send.
if RESEND_API_KEY:
    resend.api_key = RESEND_API_KEY
else:
    print("Warning: RESEND_API_KEY not set. Email sending will be disabled.")


_agent = None


def _extract_agent_text(result) -> str:
    """
    Pydantic AI Agent.run can return different attribute names across versions.
    Try common ones before falling back to str(result).
    """
    for attr in ("data", "output", "result"):
        if hasattr(result, attr):
            value = getattr(result, attr)
            return str(value)
    return str(result)

def get_agent():
    """Get or create the Agent instance. Raises error if API key is not set."""
    global _agent
    if _agent is None:
        if not OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY environment variable is not set. Please set it before using the agent.")
        
        system_prompt = """you are a proficient arduino coder that simplifies code into its simplest form. 
Generate complete, working Arduino code that is ready to upload to an Arduino board. 
Always include necessary pin definitions, setup() and loop() functions, and any required library includes.

You also have access to a database that stores Arduino-related data. You can query the database to:
- List all tables in the database
- Get the schema/structure of tables
- Query data from tables
- Get row counts from tables

Use the database tools when the user asks about stored data, logs, or historical information."""
        
        _agent = Agent(
            'openai:gpt-4o-mini', 
            system_prompt=system_prompt
        )
        
       
        @_agent.tool
        def list_database_tables(ctx: RunContext[None]) -> str:
            """List all tables available in the database. Use this to discover what data is stored."""
            try:
                if not db.is_db_access_enabled():
                    return "Database access is currently disabled. The developer has restricted database access."
                tables = db.get_tables()
                if not tables:
                    return "No tables found in the database."
                return f"Available tables: {', '.join(tables)}"
            except Exception as e:
                return f"Error listing tables: {str(e)}"
        
        @_agent.tool
        def get_table_structure(ctx: RunContext[None], table_name: str) -> str:
            """Get the schema/structure of a specific table. Use this to understand what columns and data types are in a table.
            
            Args:
                table_name: The name of the table to inspect
            """
            try:
                if not db.is_db_access_enabled():
                    return "Database access is currently disabled. The developer has restricted database access."
                return db.get_table_schema(table_name)
            except Exception as e:
                return f"Error getting table structure: {str(e)}"
        
        @_agent.tool
        def query_table_data(ctx: RunContext[None], table_name: str, limit: int = 100) -> str:
            """Query data from a specific table. Returns rows as JSON-like format.
            
            Args:
                table_name: The name of the table to query
                limit: Maximum number of rows to return (default: 100, max recommended: 1000)
            """
            try:
                if not db.is_db_access_enabled():
                    return "Database access is currently disabled. The developer has restricted database access."
                if limit > 1000:
                    limit = 1000  
                data = db.get_table_data(table_name, limit=limit)
                if not data:
                    return f"No data found in table '{table_name}'"
                return json.dumps(data, indent=2, default=str)
            except Exception as e:
                return f"Error querying table: {str(e)}"
        
        @_agent.tool
        def execute_database_query(ctx: RunContext[None], query: str) -> str:
            """Execute a SELECT query on the database. Use this for custom queries or filtering data.
            WARNING: Only SELECT queries are safe. Do not attempt INSERT, UPDATE, DELETE, or DROP operations.
            
            Args:
                query: A SQL SELECT query to execute
            """
            try:
                if not db.is_db_access_enabled():
                    return "Database access is currently disabled. The developer has restricted database access."
                
               
                query_upper = query.strip().upper()
                if not query_upper.startswith('SELECT'):
                    return "Error: Only SELECT queries are allowed for safety. INSERT, UPDATE, DELETE, and DROP operations are not permitted."
                
                results = db.execute_query(query)
                if not results:
                    return "Query executed successfully but returned no results."
                return json.dumps(results, indent=2, default=str)
            except Exception as e:
                return f"Error executing query: {str(e)}"
        
        @_agent.tool
        def get_table_row_count(ctx: RunContext[None], table_name: str) -> str:
            """Get the total number of rows in a table.
            
            Args:
                table_name: The name of the table
            """
            try:
                if not db.is_db_access_enabled():
                    return "Database access is currently disabled. The developer has restricted database access."
                count = db.get_table_row_count(table_name)
                return f"Table '{table_name}' contains {count} row(s)."
            except Exception as e:
                return f"Error getting row count: {str(e)}"
        
        @_agent.tool
        def check_database_access_status(ctx: RunContext[None]) -> str:
            """Check if database access is currently enabled or disabled."""
            status = "enabled" if db.is_db_access_enabled() else "disabled"
            return f"Database access is currently {status}."
    
    return _agent

tools_json = json.dumps(tools, indent=2)


async def generate_arduino_code(user_input: str, context: Optional[list[str]] = None) -> str:
    """
    Generate Arduino code based on user input and available tools.
    
    Args:
        user_input: The user's description of what they want to build
        context: Optional list of context lines (e.g., serial output from Arduino)
    
    Returns:
        str: Complete Arduino code ready to upload
    """
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY environment variable is not set. Please set it before using the agent.")
    
   
    tools_list = ", ".join([tool["name"].replace("_", " ") for tool in tools])
    
    prompt = f"""Generate complete Arduino code for the following request: {user_input}

Available hardware components in the Arduino kit:
{tools_list}

Requirements:
- Generate complete, working Arduino code
- Include all necessary #include statements for libraries
- Define all pin numbers clearly
- Include setup() function with pinMode configurations
- Include loop() function with the main logic
- Add comments to explain the code
- Use the simplest implementation possible
- Only use the hardware components listed above

Please provide the complete Arduino code:"""
    
   
    if context:
        context_text = "\n".join(context)
        prompt += f"\n\nAdditional context from Arduino:\n{context_text}"
    
    try:
        agent = get_agent()
        result = await agent.run(prompt)
        return _extract_agent_text(result)
    except Exception as e:
        raise Exception(f"Error generating Arduino code: {str(e)}")


async def generate_prompt(user_input: str, context: Optional[list[str]] = None) -> str:
    """
    Generate an accurate prompt/response using the ChatGPT 4.0 mini API.
    
    Args:
        user_input: The user's question or request
        context: Optional list of context lines (e.g., serial output from Arduino)
    
    Returns:
        str: The AI-generated response
    """
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY environment variable is not set. Please set it before using the agent.")
    
  
    full_prompt = user_input
    if context:
        context_text = "\n".join(context)
        full_prompt = f"{user_input}\n\nContext from Arduino:\n{context_text}"
    
    
    tools_info = f"\n\nAvailable hardware tools: {tools_json}"
    full_prompt += tools_info
    
    try:
        agent = get_agent()
        result = await agent.run(full_prompt)
        return _extract_agent_text(result)
    except Exception as e:
        raise Exception(f"Error generating prompt: {str(e)}")


def generate_arduino_code_sync(user_input: str, context: Optional[list[str]] = None) -> str:
    """
    Synchronous wrapper for generate_arduino_code.
    Use this if you're not in an async context.
    
    Args:
        user_input: The user's description of what they want to build
        context: Optional list of context lines (e.g., serial output from Arduino)
    
    Returns:
        str: Complete Arduino code ready to upload
    """
    import asyncio
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    return loop.run_until_complete(generate_arduino_code(user_input, context))


def generate_prompt_sync(user_input: str, context: Optional[list[str]] = None) -> str:
    """
    Synchronous wrapper for generate_prompt.
    Use this if you're not in an async context.
    
    Args:
        user_input: The user's question or request
        context: Optional list of context lines (e.g., serial output from Arduino)
    
    Returns:
        str: The AI-generated response
    """
    import asyncio
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    return loop.run_until_complete(generate_prompt(user_input, context))


def _build_instruction_prompt(user_prompt: str, context: Optional[list[str]] = None) -> str:
    """Create detailed instruction prompt for hardware construction and setup."""
    tools_list = ", ".join([tool["name"].replace("_", " ") for tool in tools])
    base = f"""User wants to perform the following on Arduino: {user_prompt}

Available hardware components:
{tools_list}

Write comprehensive, detailed step-by-step instructions for constructing the hardware setup needed to achieve this request. Your instructions should include:

1. **Hardware Requirements**: List all components needed (Arduino board, specific modules, wires, resistors, etc.)
2. **Physical Construction**: Detailed step-by-step wiring instructions including:
   - Which pins to connect to which components
   - Wire colors and connections (if relevant)
   - Component orientation (which way to plug in)
   - Breadboard layout (if using breadboard)
   - Any required resistors, capacitors, or other passive components
3. **Pin Connections**: Clear pin mapping (e.g., "LED positive leg → Arduino pin 13", "LED negative leg → GND")
4. **Code Setup**: Brief overview of what code needs to be uploaded
5. **Testing Steps**: How to verify the setup works correctly
6. **Troubleshooting**: Common issues and solutions

Be very specific about pin numbers, component orientations, and wiring. Include safety considerations if relevant. Make the instructions clear enough that someone can follow them without prior Arduino experience. Use clear formatting with numbered steps and sub-bullets where helpful."""
    if context:
        context_text = "\n".join(context)
        base += f"\n\nExtra context from Arduino:\n{context_text}"
    return base


def send_instruction_email(user_email: str, user_prompt: str, context: Optional[list[str]] = None) -> str:
    """
    Generate hardware instructions for the user's prompt and email them via Resend.

    Args:
        user_email: Destination email address
        user_prompt: The user's request (e.g., "flash the LED twice in 2 seconds")
        context: Optional serial/context lines from Arduino to inform the response

    Returns:
        str: Resend send result (stringified)
    """
    if not RESEND_API_KEY:
        raise ValueError("RESEND_API_KEY is not set. Set it in your environment before sending email.")
    if not user_email:
        raise ValueError("user_email is required to send instructions.")
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY is not set. Set it in your environment before generating instructions.")

    instruction_prompt = _build_instruction_prompt(user_prompt, context)

    try:
        instructions_text = generate_prompt_sync(instruction_prompt, context=None)  # context already embedded
    except Exception as e:
        raise Exception(f"Error generating instructions: {str(e)}")

    # Simple HTML wrapper; preserve newlines
    instructions_html = instructions_text.replace("\n", "<br>")

    subject = f"Arduino instructions: {user_prompt[:80]}"
    try:
        result = resend.Emails.send({
            "from": RESEND_FROM,
            "to": user_email,
            "subject": subject,
            "html": f"<p>Prompt:</p><p><b>{user_prompt}</b></p><p>Instructions:</p><p>{instructions_html}</p>"
        })
        return str(result)
    except Exception as e:
        raise Exception(f"Error sending email via Resend: {str(e)}")

