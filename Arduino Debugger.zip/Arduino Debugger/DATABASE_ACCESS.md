# Database Access for AI Agent

The AI agent now has access to the database and can query data to help with Arduino-related tasks.

## Features

The agent can:
- **List all tables** in the database
- **Get table schemas** to understand data structure
- **Query table data** with customizable limits
- **Execute custom SELECT queries** for filtering and analysis
- **Get row counts** from tables

## Database Access Control (Kill Command)

The developer can control whether the AI agent has access to the database using the kill command mechanism.

### Using the Control Script

```bash
# Enable database access
python3 control_db_access.py enable

# Disable database access (kill command)
python3 control_db_access.py disable

# Check current status
python3 control_db_access.py status

# Toggle between enabled/disabled
python3 control_db_access.py toggle
```

### Using Environment Variables

Set the `DB_ACCESS_ENABLED` environment variable:

```bash
# Enable access
export DB_ACCESS_ENABLED=true

# Disable access (kill command)
export DB_ACCESS_ENABLED=false
```

### Using Python Code

```python
import db

# Disable database access (kill command)
db.set_db_access_enabled(False)

# Enable database access
db.set_db_access_enabled(True)

# Check status
if db.is_db_access_enabled():
    print("Database access is enabled")
```

## Safety Features

1. **Read-only by default**: The agent can only execute SELECT queries. INSERT, UPDATE, DELETE, and DROP operations are blocked.

2. **Query limits**: Table data queries are limited to 1000 rows by default to prevent excessive data retrieval.

3. **Access control**: The kill command allows developers to instantly disable database access if needed.

## Agent Tools

The agent has access to these database tools:

- `list_database_tables()` - List all available tables
- `get_table_structure(table_name)` - Get schema of a table
- `query_table_data(table_name, limit=100)` - Query data from a table
- `execute_database_query(query)` - Execute custom SELECT queries
- `get_table_row_count(table_name)` - Get row count
- `check_database_access_status()` - Check if access is enabled

## Example Usage

When the agent is asked questions like:
- "What data is stored in the database?"
- "Show me the Arduino logs from yesterday"
- "How many records are in the sensor_data table?"
- "What's the structure of the events table?"

The agent will automatically use the database tools to answer these questions, provided database access is enabled.

## Default State

By default, database access is **enabled** (controlled by `DB_ACCESS_ENABLED` environment variable, defaults to `true`).

