#!/usr/bin/env python3
"""Test script to check database connectivity."""

import sys
import os

print("=" * 60)
print("Database Connection Test")
print("=" * 60)

# Check if MySQL libraries are installed
print("\n1. Checking MySQL libraries...")
try:
    import mysql.connector
    print("   ✓ mysql-connector-python is installed")
    mysql_available = True
except ImportError:
    print("   ✗ mysql-connector-python is NOT installed")
    mysql_available = False

try:
    import pymysql
    print("   ✓ pymysql is installed")
    pymysql_available = True
except ImportError:
    print("   ✗ pymysql is NOT installed")
    pymysql_available = False

if not mysql_available and not pymysql_available:
    print("\n❌ ERROR: No MySQL library found!")
    print("   Install one with:")
    print("     pip3 install mysql-connector-python")
    print("     or")
    print("     pip3 install pymysql")
    sys.exit(1)

# Check environment variables
print("\n2. Checking database configuration...")
db_host = os.getenv("DB_HOST", "localhost")
db_port = os.getenv("DB_PORT", "3306")
db_user = os.getenv("DB_USER", "root")
db_password = os.getenv("DB_PASSWORD", "")
db_name = os.getenv("DB_NAME", "arduino.log")

print(f"   Host: {db_host}")
print(f"   Port: {db_port}")
print(f"   User: {db_user}")
print(f"   Password: {'*' * len(db_password) if db_password else '(empty)'}")
print(f"   Database: {db_name}")

# Test connection
print("\n3. Testing database connection...")
try:
    from db import test_connection, get_connection
    
    result = test_connection()
    if result:
        print(f"   ✓ {result}")
        print("\n✅ SUCCESS: Database connection is working!")
        
        # Try a simple query
        print("\n4. Testing a simple query...")
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            print(f"   ✓ Found {len(tables)} table(s) in database")
            if tables:
                print("   Tables:")
                for table in tables:
                    print(f"     - {table[0]}")
            cursor.close()
            conn.close()
        except Exception as e:
            print(f"   ⚠️  Query test failed: {e}")
    else:
        print("   ✗ Connection failed (no error message returned)")
        print("\n❌ FAILED: Could not connect to database")
        print("\nTroubleshooting:")
        print("   1. Make sure MySQL/MariaDB server is running")
        print("   2. Check that the database 'arduino.log' exists")
        print("   3. Verify your credentials match phpMyAdmin")
        print("   4. Try setting environment variables:")
        print("      export DB_HOST='127.0.0.1'")
        print("      export DB_USER='your_username'")
        print("      export DB_PASSWORD='your_password'")
        print("      export DB_NAME='your_database'")
        
except ImportError as e:
    print(f"   ✗ Could not import db module: {e}")
    sys.exit(1)
except Exception as e:
    print(f"   ✗ Error: {e}")
    print("\n❌ FAILED: Database connection error")
    print(f"\nError details: {type(e).__name__}: {e}")

print("\n" + "=" * 60)

