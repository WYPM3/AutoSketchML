# Arduino to Database Data Transfer Overview

## 📊 System Architecture

```
┌─────────────┐         ┌──────────────┐         ┌─────────────┐
│   Arduino   │  Serial │   Python     │   SQL    │  MySQL DB   │
│   Device    │────────▶│   Script     │────────▶│  (phpMyAdmin)│
│             │  (9600) │              │  INSERT │             │
└─────────────┘         └──────────────┘         └─────────────┘
     │                        │                        │
     │                        │                        │
  Sensor                    Parses                 Stores
  Readings              SENSOR: format         sensor_logs table
```

## 🔄 Data Flow

### Step 1: Arduino Sensor Reading
- Arduino reads sensor data from analog pin `A0` (or configured sensor)
- Reading interval: Every 5 seconds (configurable)
- Data includes: sensor value, device ID, sensor type, units, battery level, signal strength

### Step 2: Serial Communication
- Arduino sends data via Serial port at 9600 baud
- Format: `SENSOR:device_id|sensor_type|sensor_value|units|battery_level|signal_strength`
- Example: `SENSOR:ARDUINO_001|analog|513.0|raw|100.0|100`

### Step 3: Python Script Processing
- `read_arduino_sensor.py` monitors the serial port
- Parses incoming `SENSOR:` messages
- Validates data format (6 pipe-separated values)
- Converts values to appropriate types (float, int)

### Step 4: Database Storage
- `db.insert_sensor_log()` inserts data into `sensor_logs` table
- Database: `arduino.log` (or `Arduino.log` on some systems)
- Table: `sensor_logs`
- Timestamps: `logged_at` and `received_at` are automatically set

## 📋 Data Format

### Serial Message Format
```
SENSOR:device_id|sensor_type|sensor_value|units|battery_level|signal_strength
```

### Field Descriptions

| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `device_id` | varchar(32) | Unique device identifier | `ARDUINO_001` |
| `sensor_type` | varchar(32) | Type of sensor | `analog`, `temperature`, `humidity` |
| `sensor_value` | float | Sensor reading value | `513.0`, `25.5` |
| `units` | varchar(16) | Measurement units | `raw`, `C`, `F`, `%`, `V` |
| `battery_level` | float | Battery percentage | `100.0`, `85.5` |
| `signal_strength` | int | Signal strength (0-100) | `100`, `75` |

### Database Schema

```sql
CREATE TABLE sensor_logs (
    id INT(16) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    device_id VARCHAR(32) NOT NULL,
    sensor_type VARCHAR(32) NOT NULL,
    sensor_value FLOAT NOT NULL,
    units VARCHAR(16) NOT NULL,
    battery_level FLOAT NOT NULL,
    signal_strength INT(16) NOT NULL,
    logged_at TIMESTAMP NOT NULL,
    received_at TIMESTAMP NOT NULL
);
```

## 🔧 Components

### 1. Arduino Code
**File:** (Upload to Arduino)
- Reads sensor data periodically
- Formats data as `SENSOR:` message
- Sends via Serial at 9600 baud
- Configurable device ID, sensor type, and units

### 2. Python Script: `read_arduino_sensor.py`
**Purpose:** Bridge between Arduino and database

**Functions:**
- `find_arduino_port()` - Auto-detects Arduino serial port
- `parse_sensor_data(line)` - Parses `SENSOR:` messages
- `read_and_store_sensor_data()` - Main loop that reads and stores data

**Usage:**
```bash
# Run continuously
python3 read_arduino_sensor.py

# Run for 60 seconds
python3 read_arduino_sensor.py --once 60
```

### 3. Database Module: `db.py`
**Purpose:** Database operations

**Key Functions:**
- `insert_sensor_log()` - Inserts sensor reading into database
- `get_table_data()` - Retrieves stored sensor data
- `get_table_row_count()` - Gets total number of readings
- `fix_sensor_logs_table()` - Sets up AUTO_INCREMENT for id field

### 4. Database: MySQL/MariaDB
**Location:** `localhost:3306`
**Database:** `arduino.log` or `Arduino.log`
**Access:** phpMyAdmin at `http://localhost/phpmyadmin/`

## 📥 Data Transfer Process

### Complete Flow Example

1. **Arduino reads sensor:**
   ```
   Analog pin A0 = 513 (0-1023 range)
   ```

2. **Arduino formats and sends:**
   ```
   SENSOR:ARDUINO_001|analog|513.0|raw|100.0|100
   ```

3. **Python script receives:**
   ```
   Line received: "SENSOR:ARDUINO_001|analog|513.0|raw|100.0|100"
   Parsed: {
       'device_id': 'ARDUINO_001',
       'sensor_type': 'analog',
       'sensor_value': 513.0,
       'units': 'raw',
       'battery_level': 100.0,
       'signal_strength': 100
   }
   ```

4. **Database INSERT:**
   ```sql
   INSERT INTO sensor_logs 
   (device_id, sensor_type, sensor_value, units, battery_level, signal_strength, logged_at, received_at)
   VALUES ('ARDUINO_001', 'analog', 513.0, 'raw', 100.0, 100, NOW(), NOW())
   ```

5. **Result in database:**
   ```
   id: 1
   device_id: ARDUINO_001
   sensor_type: analog
   sensor_value: 513.0
   units: raw
   battery_level: 100.0
   signal_strength: 100
   logged_at: 2025-12-05 15:11:26
   received_at: 2025-12-05 15:11:26
   ```

## ⚙️ Configuration

### Arduino Configuration
- **Baud Rate:** 9600
- **Serial Port:** Auto-detected (typically `/dev/cu.usbmodemXXXX` on macOS)
- **Reading Interval:** 5 seconds (configurable in Arduino code)
- **Device ID:** Stored in EEPROM, default `ARDUINO_001`

### Database Configuration
Environment variables (or defaults):
- `DB_HOST`: `localhost`
- `DB_PORT`: `3306`
- `DB_USER`: `root`
- `DB_PASSWORD`: (set in environment)
- `DB_NAME`: `arduino.log`

### Access Control
Database access can be enabled/disabled:
```bash
python3 control_db_access.py enable   # Enable
python3 control_db_access.py disable  # Disable (kill command)
python3 control_db_access.py status   # Check status
```

## 📊 Monitoring and Verification

### View Data in Database
```bash
# Query recent readings
python3 -c "import db; import json; print(json.dumps(db.get_table_data('sensor_logs', limit=10), indent=2, default=str))"

# Get total count
python3 -c "import db; print(f'Total readings: {db.get_table_row_count(\"sensor_logs\")}')"
```

### View in phpMyAdmin
Navigate to:
```
http://localhost/phpmyadmin/index.php?route=/table/structure&db=Arduino.log&table=sensor_logs
```

### Monitor Serial Output
```bash
# See all Arduino serial output (for debugging)
python3 monitor_arduino.py --once 30
```

## 🔍 Troubleshooting

### Common Issues

1. **Port Busy Error**
   - **Cause:** Another program using the serial port
   - **Solution:** Close Arduino IDE Serial Monitor or other serial tools

2. **No Data Received**
   - **Cause:** Arduino not sending data or wrong baud rate
   - **Solution:** Check Arduino code is uploaded and running

3. **Database Insert Fails**
   - **Cause:** Database access disabled or connection issue
   - **Solution:** Run `python3 control_db_access.py enable` and check database connection

4. **Wrong Data Format**
   - **Cause:** Arduino sending incorrect format
   - **Solution:** Verify Arduino code sends `SENSOR:` prefix with 6 pipe-separated values

## 📈 Performance

- **Reading Frequency:** 1 reading every 5 seconds (configurable)
- **Data Size:** ~100 bytes per reading
- **Database Storage:** ~200 bytes per row (with timestamps)
- **Throughput:** ~12 readings/minute, ~720 readings/hour

## 🔐 Security Considerations

- Database access can be disabled via kill command
- Only SELECT queries allowed for safety (INSERT is controlled via `insert_sensor_log()`)
- Serial port access requires physical connection
- No authentication on serial communication (local only)

## 🚀 Future Enhancements

Potential improvements:
- Multiple sensor support (multiple `SENSOR:` messages per reading)
- Data validation and filtering
- Error handling and retry logic
- Data compression for high-frequency readings
- Web dashboard for real-time visualization
- Alert system for threshold violations

